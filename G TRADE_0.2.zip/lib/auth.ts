"use client"

import { create } from "zustand"
import { persist } from "zustand/middleware"

export interface User {
  id: string
  email: string
  name: string
  role: "buyer" | "seller"
  avatar?: string
  // Seller specific fields
  businessName?: string
  gst?: string
  address?: string
  phone?: string
  description?: string
  rating?: number
}

interface AuthState {
  user: User | null
  isAuthenticated: boolean
  login: (email: string, password: string, role: "buyer" | "seller") => Promise<boolean>
  signup: (userData: Partial<User> & { password: string }) => Promise<boolean>
  logout: () => void
  updateProfile: (userData: Partial<User>) => void
}

export const useAuth = create<AuthState>()(
  persist(
    (set, get) => ({
      user: null,
      isAuthenticated: false,

      login: async (email: string, password: string, role: "buyer" | "seller") => {
        // Simulate API call
        await new Promise((resolve) => setTimeout(resolve, 1000))

        // Mock authentication - in real app, this would call your backend
        if (email && password) {
          const mockUser: User = {
            id: Math.random().toString(36).substr(2, 9),
            email,
            name: email.split("@")[0],
            role,
            ...(role === "seller" && {
              businessName: "Sample Business",
              rating: 4.5,
            }),
          }

          set({ user: mockUser, isAuthenticated: true })
          return true
        }
        return false
      },

      signup: async (userData) => {
        // Simulate API call
        await new Promise((resolve) => setTimeout(resolve, 1000))

        const newUser: User = {
          id: Math.random().toString(36).substr(2, 9),
          email: userData.email!,
          name: userData.name!,
          role: userData.role!,
          businessName: userData.businessName,
          gst: userData.gst,
          address: userData.address,
          phone: userData.phone,
        }

        set({ user: newUser, isAuthenticated: true })
        return true
      },

      logout: () => {
        set({ user: null, isAuthenticated: false })
      },

      updateProfile: (userData) => {
        const currentUser = get().user
        if (currentUser) {
          set({ user: { ...currentUser, ...userData } })
        }
      },
    }),
    {
      name: "auth-storage",
    },
  ),
)
