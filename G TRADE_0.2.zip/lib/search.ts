export interface SearchFilters {
  category?: string
  priceRange?: [number, number]
  rating?: number
  ecoVerified?: boolean
  sortBy?: "relevance" | "price-low" | "price-high" | "rating" | "newest"
}

export interface SearchResult {
  products: any[]
  totalCount: number
  filters: {
    categories: { name: string; count: number }[]
    priceRange: [number, number]
    avgRating: number
  }
}

// Import products data
import { products } from "./products"

export function searchProducts(query: string, filters: SearchFilters = {}): SearchResult {
  let filteredProducts = [...products]

  // Text search
  if (query.trim()) {
    const searchTerm = query.toLowerCase()
    filteredProducts = filteredProducts.filter(
      (product) =>
        product.name.toLowerCase().includes(searchTerm) ||
        product.description.toLowerCase().includes(searchTerm) ||
        product.category.toLowerCase().includes(searchTerm) ||
        product.tags?.some((tag: string) => tag.toLowerCase().includes(searchTerm)),
    )
  }

  // Category filter
  if (filters.category) {
    filteredProducts = filteredProducts.filter((product) => product.category === filters.category)
  }

  // Price range filter
  if (filters.priceRange) {
    const [min, max] = filters.priceRange
    filteredProducts = filteredProducts.filter((product) => product.price >= min && product.price <= max)
  }

  // Rating filter
  if (filters.rating) {
    filteredProducts = filteredProducts.filter((product) => product.rating >= filters.rating)
  }

  // Eco verified filter
  if (filters.ecoVerified) {
    filteredProducts = filteredProducts.filter((product) => product.ecoVerified === true)
  }

  // Sorting
  switch (filters.sortBy) {
    case "price-low":
      filteredProducts.sort((a, b) => a.price - b.price)
      break
    case "price-high":
      filteredProducts.sort((a, b) => b.price - a.price)
      break
    case "rating":
      filteredProducts.sort((a, b) => b.rating - a.rating)
      break
    case "newest":
      filteredProducts.sort(
        (a, b) => new Date(b.dateAdded || "2024-01-01").getTime() - new Date(a.dateAdded || "2024-01-01").getTime(),
      )
      break
    default: // relevance
      // Keep original order for relevance
      break
  }

  // Generate filter metadata
  const categories = [...new Set(products.map((p: any) => p.category))].map((cat) => ({
    name: cat,
    count: products.filter((p: any) => p.category === cat).length,
  }))

  const prices = products.map((p: any) => p.price)
  const priceRange: [number, number] = [Math.min(...prices), Math.max(...prices)]

  const avgRating = products.reduce((sum: number, p: any) => sum + p.rating, 0) / products.length

  return {
    products: filteredProducts,
    totalCount: filteredProducts.length,
    filters: {
      categories,
      priceRange,
      avgRating,
    },
  }
}
