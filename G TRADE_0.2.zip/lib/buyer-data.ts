export interface BuyerOrder {
  id: string
  items: {
    productId: string
    productName: string
    productImage: string
    sellerName: string
    quantity: number
    price: number
    total: number
  }[]
  totalAmount: number
  status: "pending" | "confirmed" | "shipped" | "delivered" | "cancelled"
  orderDate: string
  estimatedDelivery: string
  shippingAddress: {
    name: string
    street: string
    city: string
    state: string
    zipCode: string
    country: string
  }
  paymentMethod: string
  trackingNumber?: string
}

export interface EcoImpact {
  totalOrders: number
  plasticSaved: number // in grams
  carbonOffset: number // in kg CO2
  treesPlanted: number
  waterSaved: number // in liters
}

export const mockBuyerOrders: BuyerOrder[] = [
  {
    id: "BO001",
    items: [
      {
        productId: "hg001",
        productName: "Bamboo Toothbrush Set (4 Pack)",
        productImage: "/products/bamboo-toothbrush.png",
        sellerName: "EcoLife Store",
        quantity: 2,
        price: 12.99,
        total: 25.98,
      },
      {
        productId: "pc001",
        productName: "Natural Handmade Soap Bar Set",
        productImage: "/products/handmade-soap-set.png",
        sellerName: "Natural Soap Co",
        quantity: 1,
        price: 18.99,
        total: 18.99,
      },
    ],
    totalAmount: 44.97,
    status: "delivered",
    orderDate: "2025-01-10",
    estimatedDelivery: "2025-01-15",
    shippingAddress: {
      name: "John Smith",
      street: "123 Main St",
      city: "Portland",
      state: "OR",
      zipCode: "97201",
      country: "USA",
    },
    paymentMethod: "Credit Card",
    trackingNumber: "TRK123456789",
  },
  {
    id: "BO002",
    items: [
      {
        productId: "hg002",
        productName: "Organic Cotton Bath Towels",
        productImage: "/products/organic-towels.png",
        sellerName: "Pure Living",
        quantity: 1,
        price: 34.99,
        total: 34.99,
      },
    ],
    totalAmount: 34.99,
    status: "shipped",
    orderDate: "2025-01-16",
    estimatedDelivery: "2025-01-20",
    shippingAddress: {
      name: "John Smith",
      street: "123 Main St",
      city: "Portland",
      state: "OR",
      zipCode: "97201",
      country: "USA",
    },
    paymentMethod: "PayPal",
    trackingNumber: "TRK987654321",
  },
  {
    id: "BO003",
    items: [
      {
        productId: "eg001",
        productName: "Eco-Friendly Gift Hamper",
        productImage: "/products/eco-gift-hamper.png",
        sellerName: "Green Gifts Co",
        quantity: 1,
        price: 49.99,
        total: 49.99,
      },
    ],
    totalAmount: 49.99,
    status: "confirmed",
    orderDate: "2025-01-18",
    estimatedDelivery: "2025-01-23",
    shippingAddress: {
      name: "John Smith",
      street: "123 Main St",
      city: "Portland",
      state: "OR",
      zipCode: "97201",
      country: "USA",
    },
    paymentMethod: "Credit Card",
  },
]

export const mockEcoImpact: EcoImpact = {
  totalOrders: 12,
  plasticSaved: 2450, // grams
  carbonOffset: 15.6, // kg CO2
  treesPlanted: 3,
  waterSaved: 180, // liters
}

export function getBuyerOrders(buyerId: string): BuyerOrder[] {
  // In a real app, this would filter by buyer ID
  return mockBuyerOrders
}

export function getEcoImpact(buyerId: string): EcoImpact {
  // In a real app, this would calculate buyer-specific impact
  return mockEcoImpact
}
