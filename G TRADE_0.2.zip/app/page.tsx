"use client"
import { useRouter } from "next/navigation"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Leaf, Recycle, Heart, Star, Award, ArrowRight, ChevronLeft, ChevronRight } from "lucide-react"
import Image from "next/image"

const allProducts = [
  // Home & Garden
  {
    name: "Bamboo Plant Pots Set",
    price: "$18.99",
    originalPrice: "$24.99",
    rating: 4.8,
    image: "/placeholder-cox48.png",
    seller: "Garden Green",
    badge: "Eco-Friendly",
    badgeColor: "bg-green-500",
    category: "Home & Garden",
  },
  {
    name: "Solar Garden Lights",
    price: "$32.99",
    originalPrice: "$39.99",
    rating: 4.7,
    image: "/placeholder-kegoc.png",
    seller: "Eco Garden",
    badge: "Solar Powered",
    badgeColor: "bg-yellow-500",
    category: "Home & Garden",
  },
  // Handmade
  {
    name: "Handwoven Jute Bag",
    price: "$24.99",
    originalPrice: "$29.99",
    rating: 4.9,
    image: "/handwoven-jute-bag.png",
    seller: "Artisan Crafts",
    badge: "Handmade",
    badgeColor: "bg-purple-500",
    category: "Handmade",
  },
  {
    name: "Hand-carved Wooden Bowl",
    price: "$28.99",
    originalPrice: "$35.99",
    rating: 4.8,
    image: "/placeholder-hkttl.png",
    seller: "Wood Artisans",
    badge: "Handcrafted",
    badgeColor: "bg-purple-500",
    category: "Handmade",
  },
  // Personal Care
  {
    name: "Bamboo Toothbrush Set",
    price: "$12.99",
    originalPrice: "$16.99",
    rating: 4.8,
    image: "/placeholder-cox48.png",
    seller: "EcoLife Store",
    badge: "Bestseller",
    badgeColor: "bg-emerald-500",
    category: "Personal Care",
  },
  {
    name: "Organic Shampoo Bar",
    price: "$15.99",
    originalPrice: "$19.99",
    rating: 4.6,
    image: "/placeholder-kegoc.png",
    seller: "Pure Care",
    badge: "Organic",
    badgeColor: "bg-green-500",
    category: "Personal Care",
  },
  // Kitchen Essentials
  {
    name: "Bamboo Cutting Board",
    price: "$22.99",
    originalPrice: "$28.99",
    rating: 4.7,
    image: "/placeholder-hkttl.png",
    seller: "Kitchen Green",
    badge: "Sustainable",
    badgeColor: "bg-green-500",
    category: "Kitchen Essentials",
  },
  {
    name: "Stainless Steel Straws",
    price: "$9.99",
    originalPrice: "$14.99",
    rating: 4.8,
    image: "/placeholder-cox48.png",
    seller: "Zero Waste Co",
    badge: "Reusable",
    badgeColor: "bg-blue-500",
    category: "Kitchen Essentials",
  },
  // Stationery
  {
    name: "Recycled Paper Notebooks",
    price: "$8.99",
    originalPrice: "$12.99",
    rating: 4.6,
    image: "/placeholder-hkttl.png",
    seller: "Green Stationery",
    badge: "Eco-Friendly",
    badgeColor: "bg-blue-500",
    category: "Stationery",
  },
  {
    name: "Bamboo Pen Set",
    price: "$16.99",
    originalPrice: "$21.99",
    rating: 4.5,
    image: "/placeholder-kegoc.png",
    seller: "Eco Write",
    badge: "Sustainable",
    badgeColor: "bg-green-500",
    category: "Stationery",
  },
  // Cleaning
  {
    name: "Natural Cleaning Kit",
    price: "$26.99",
    originalPrice: "$32.99",
    rating: 4.7,
    image: "/placeholder-cox48.png",
    seller: "Clean Green",
    badge: "Chemical-Free",
    badgeColor: "bg-teal-500",
    category: "Cleaning",
  },
  // Organic Food
  {
    name: "Organic Cotton Towels",
    price: "$34.99",
    originalPrice: "$42.99",
    rating: 4.7,
    image: "/placeholder-kegoc.png",
    seller: "Pure Living",
    badge: "Organic",
    badgeColor: "bg-green-500",
    category: "Organic Food",
  },
]

const categories = [
  { name: "Home & Garden", emoji: "🏠", color: "bg-green-100 hover:bg-green-200", slug: "home-garden" },
  { name: "Handmade", emoji: "🎨", color: "bg-purple-100 hover:bg-purple-200", slug: "handmade" },
  { name: "Eco Gifts", emoji: "🎁", color: "bg-red-100 hover:bg-red-200", slug: "eco-gifts" },
  { name: "Personal Care", emoji: "🧴", color: "bg-pink-100 hover:bg-pink-200", slug: "personal-care" },
  { name: "Kitchen Essentials", emoji: "🍽️", color: "bg-orange-100 hover:bg-orange-200", slug: "kitchen-essentials" },
  { name: "Footwear", emoji: "👟", color: "bg-indigo-100 hover:bg-indigo-200", slug: "footwear" },
  { name: "Bags", emoji: "👜", color: "bg-yellow-100 hover:bg-yellow-200", slug: "bags" },
  { name: "Stationery", emoji: "📝", color: "bg-blue-100 hover:bg-blue-200", slug: "stationery" },
  { name: "Cleaning", emoji: "🧽", color: "bg-teal-100 hover:bg-teal-200", slug: "cleaning" },
  { name: "Organic Food", emoji: "🥬", color: "bg-lime-100 hover:bg-lime-200", slug: "organic-food" },
]

export default function HomePage() {
  const router = useRouter()
  const featuredProducts = allProducts.slice(0, 4)

  const handleCategoryClick = (categorySlug: string) => {
    router.push(`/category/${categorySlug}`)
  }

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Header />

      <main className="flex-1">
        {/* Hero Section */}
        <section className="relative h-[70vh] overflow-hidden">
          <div className="absolute inset-0">
            <Image src="/lush-forest-canopy.png" alt="Sustainable Forest" fill className="object-cover" priority />
            <div className="absolute inset-0 bg-gradient-to-r from-forest-green/60 via-sage-green/40 to-transparent" />
          </div>

          <div className="relative z-10 container mx-auto px-4 h-full flex items-center">
            <div className="max-w-2xl text-white space-y-6">
              <div className="space-y-2">
                <p className="text-lg font-medium tracking-wide opacity-90">Best in Home & Living</p>
                <h1 className="text-5xl md:text-6xl font-bold leading-tight">
                  Warm, Green, <span className="text-mint-white">Serene</span>
                </h1>
              </div>
              <p className="text-xl opacity-90 leading-relaxed max-w-lg">
                Discover curated sustainable products that bring harmony to your home and peace to the planet.
              </p>
              <Button
                size="lg"
                className="bg-white text-forest-green hover:bg-mint-white px-8 py-4 text-lg font-semibold rounded-full shadow-lg hover:shadow-xl transition-all duration-300"
              >
                SHOP SUSTAINABLE
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
            </div>
          </div>
        </section>

        {/* Category Navigation - Horizontal Scroll */}
        <section className="py-6 bg-white border-b border-border">
          <div className="container mx-auto px-4">
            <div className="flex items-center space-x-8 overflow-x-auto scrollbar-hide">
              {categories.map((category, index) => (
                <Button
                  key={index}
                  variant="ghost"
                  onClick={() => handleCategoryClick(category.slug)}
                  className={`whitespace-nowrap px-6 py-2 font-medium text-sm tracking-wide hover:text-sage-green transition-colors duration-200 ${
                    index === 0 ? "text-sage-green border-b-2 border-sage-green" : "text-muted-foreground"
                  }`}
                >
                  <span className="mr-2">{category.emoji}</span>
                  {category.name.toUpperCase()}
                </Button>
              ))}
            </div>
          </div>
        </section>

        {/* Featured Products */}
        <section className="py-12 bg-mint-white">
          <div className="container mx-auto px-4">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              {[
                {
                  name: "Coconut Shell Candle Cup",
                  subtitle: "Eco-Friendly Scented Soy Wax",
                  price: "₹649",
                  originalPrice: "₹799",
                  image: "/organic-cotton-yoga-mat.png",
                  badge: "BESTSELLER",
                  rating: 4.8,
                },
                {
                  name: "Handmade Macrame Wall Hanging",
                  subtitle: "Yellow-Brown Boho Style",
                  price: "₹1,499",
                  originalPrice: "₹1,899",
                  image: "/ceramic-planter-collection.png",
                  badge: "NEW",
                  rating: 4.9,
                },
                {
                  name: "Pure Lemongrass Essential Oil",
                  subtitle: "100% Natural & Organic",
                  price: "₹799",
                  originalPrice: "₹999",
                  image: "/placeholder-6pdh1.png",
                  badge: "ORGANIC",
                  rating: 4.7,
                },
                {
                  name: "Coconut Shell Pet Shaped Planter Pots",
                  subtitle: "Ideal for Small Plants",
                  price: "₹549",
                  originalPrice: "₹699",
                  image: "/mindful-home-zen.png",
                  badge: "ECO-FRIENDLY",
                  rating: 4.6,
                },
              ].map((product, index) => (
                <Card
                  key={index}
                  className="group hover:shadow-lg transition-all duration-300 border-0 bg-white rounded-2xl overflow-hidden"
                >
                  <CardContent className="p-0">
                    <div className="relative">
                      <Image
                        src={product.image || "/placeholder.svg"}
                        alt={product.name}
                        width={300}
                        height={300}
                        className="w-full h-64 object-cover"
                      />
                      <Badge className="absolute top-3 left-3 bg-sage-green text-white text-xs px-2 py-1 rounded-full">
                        {product.badge}
                      </Badge>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="absolute top-3 right-3 bg-white/80 hover:bg-white rounded-full p-2"
                      >
                        <Heart className="h-4 w-4 text-stone-gray" />
                      </Button>
                    </div>
                    <div className="p-4 space-y-2">
                      <h3 className="font-semibold text-foreground line-clamp-1">{product.name}</h3>
                      <p className="text-sm text-muted-foreground line-clamp-1">{product.subtitle}</p>
                      <div className="flex items-center space-x-1">
                        {[...Array(5)].map((_, i) => (
                          <Star
                            key={i}
                            className={`h-3 w-3 ${i < Math.floor(product.rating) ? "fill-yellow-400 text-yellow-400" : "fill-gray-200 text-gray-200"}`}
                          />
                        ))}
                        <span className="text-xs text-muted-foreground ml-1">({product.rating})</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <span className="font-bold text-sage-green">{product.price}</span>
                        <span className="text-sm text-muted-foreground line-through">{product.originalPrice}</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
            <div className="text-center mt-8">
              <Button
                variant="outline"
                className="border-sage-green text-sage-green hover:bg-sage-green hover:text-white bg-transparent"
              >
                VIEW ALL
              </Button>
            </div>
          </div>
        </section>

        {/* Curated Collections */}
        <section className="py-16 bg-white">
          <div className="container mx-auto px-4">
            <div className="flex items-center justify-between mb-8">
              <div>
                <p className="text-sm text-muted-foreground mb-1">Best in Lifestyle</p>
                <h2 className="text-3xl font-bold text-foreground">
                  Curated for <span className="text-sage-green">Thoughtful Homes</span>
                </h2>
              </div>
              <div className="flex space-x-2">
                <Button variant="outline" size="sm" className="rounded-full p-2 bg-transparent">
                  <ChevronLeft className="h-4 w-4" />
                </Button>
                <Button variant="outline" size="sm" className="rounded-full p-2 bg-transparent">
                  <ChevronRight className="h-4 w-4" />
                </Button>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              {[
                {
                  title: "Ceramics",
                  subtitle: "Handcrafted pottery for mindful living",
                  image: "/ceramic-planter-collection.png",
                  category: "HOME DECOR",
                },
                {
                  title: "Cast Iron Cookware",
                  subtitle: "Traditional cooking for modern kitchens",
                  image: "/placeholder-xtmiy.png",
                  category: "KITCHEN",
                },
                {
                  title: "Essential Oils",
                  subtitle: "Pure aromatherapy for wellness",
                  image: "/placeholder-3wikv.png",
                  category: "WELLNESS",
                },
                {
                  title: "Fragrance Diffusers",
                  subtitle: "Natural scents for peaceful spaces",
                  image: "/placeholder-5ul1t.png",
                  category: "HOME DECOR",
                },
              ].map((item, index) => (
                <Card
                  key={index}
                  className="group cursor-pointer hover:shadow-lg transition-all duration-300 border-0 rounded-2xl overflow-hidden"
                >
                  <CardContent className="p-0">
                    <div className="relative h-48">
                      <Image
                        src={item.image || "/placeholder.svg"}
                        alt={item.title}
                        fill
                        className="object-cover group-hover:scale-105 transition-transform duration-300"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
                      <div className="absolute bottom-4 left-4 text-white">
                        <p className="text-xs font-medium opacity-80 mb-1">{item.category}</p>
                        <h3 className="text-lg font-bold mb-1">{item.title}</h3>
                        <p className="text-sm opacity-90">{item.subtitle}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* Sustainable Swaps Education */}
        <section className="py-16 bg-mint-white">
          <div className="container mx-auto px-4">
            <div className="text-center mb-12">
              <div className="flex items-center justify-center space-x-2 mb-4">
                <Leaf className="h-6 w-6 text-sage-green" />
                <p className="text-sm font-medium text-sage-green tracking-wide">LEARN WITH LOVE</p>
              </div>
              <h2 className="text-3xl font-bold text-foreground mb-4">Easy Sustainable Swaps</h2>
              <p className="text-muted-foreground max-w-2xl mx-auto">
                Only sustainability advice that can help you get started with a plastic-free and earth-friendly
                lifestyle.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              {[
                {
                  title: "Food Wrap",
                  subtitle: "Replace plastic wrap with beeswax wraps",
                  image: "/sustainable-swaps.png",
                  tip: "Reusable & biodegradable",
                },
                {
                  title: "Bamboo Speakers",
                  subtitle: "Eco-friendly tech accessories",
                  image: "/placeholder-m5wmt.png",
                  tip: "Sustainable materials",
                },
                {
                  title: "Shampoo Bar",
                  subtitle: "Zero waste hair care solution",
                  image: "/garden-to-table-harvest.png",
                  tip: "Plastic-free packaging",
                },
                {
                  title: "Water Saving Devices",
                  subtitle: "Smart conservation for your home",
                  image: "/mindful-home-zen.png",
                  tip: "Reduce water usage",
                },
              ].map((swap, index) => (
                <Card
                  key={index}
                  className="group hover:shadow-lg transition-all duration-300 border-0 rounded-2xl overflow-hidden bg-white"
                >
                  <CardContent className="p-0">
                    <div className="relative h-48">
                      <Image src={swap.image || "/placeholder.svg"} alt={swap.title} fill className="object-cover" />
                      <Badge className="absolute top-3 left-3 bg-sage-green text-white text-xs px-2 py-1 rounded-full">
                        {swap.tip}
                      </Badge>
                    </div>
                    <div className="p-4">
                      <h3 className="font-semibold text-foreground mb-1">{swap.title}</h3>
                      <p className="text-sm text-muted-foreground mb-3">{swap.subtitle}</p>
                      <Button
                        variant="outline"
                        size="sm"
                        className="text-sage-green border-sage-green hover:bg-sage-green hover:text-white bg-transparent"
                      >
                        Learn More
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* Video Section */}
        <section className="py-16 bg-white">
          <div className="container mx-auto px-4">
            <div className="relative rounded-3xl overflow-hidden max-w-4xl mx-auto">
              <div className="relative w-full h-96">
                <iframe
                  width="100%"
                  height="100%"
                  src="https://www.youtube.com/embed/8q7_aV8eLUE?rel=0&modestbranding=1&showinfo=0"
                  title="Your Journey to Sustainable Living"
                  frameBorder="0"
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                  allowFullScreen
                  className="rounded-3xl"
                ></iframe>
              </div>
              <div className="absolute bottom-6 left-6 text-white bg-black/50 p-4 rounded-lg backdrop-blur-sm">
                <h3 className="text-2xl font-bold mb-2">Your Journey to Sustainable Living</h3>
                <p className="opacity-90">Discover how small changes create big impact</p>
              </div>
            </div>
          </div>
        </section>

        {/* Impact Stats */}
        <section className="py-16 bg-sage-green text-white">
          <div className="container mx-auto px-4">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold mb-4">Our Impact Together</h2>
              <p className="text-mint-white text-lg max-w-2xl mx-auto">
                Every purchase contributes to a more sustainable future
              </p>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
              {[
                { value: "10K+", label: "Eco Products", icon: <Leaf className="h-8 w-8 mx-auto mb-2" /> },
                { value: "5K+", label: "Happy Customers", icon: <Heart className="h-8 w-8 mx-auto mb-2" /> },
                { value: "500+", label: "Verified Sellers", icon: <Award className="h-8 w-8 mx-auto mb-2" /> },
                { value: "2M kg", label: "Plastic Saved", icon: <Recycle className="h-8 w-8 mx-auto mb-2" /> },
              ].map((stat, index) => (
                <div key={index} className="space-y-3">
                  {stat.icon}
                  <div className="text-4xl font-bold">{stat.value}</div>
                  <div className="text-sm font-medium opacity-90 uppercase tracking-wide">{stat.label}</div>
                </div>
              ))}
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  )
}
