"use client"

import type React from "react"

import { useState, useEffect, Suspense } from "react"
import { useSearchParams } from "next/navigation"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Search, Grid, List, Loader2 } from "lucide-react"
import { ProductCard } from "@/components/product-card"
import { SearchFiltersComponent } from "@/components/search/search-filters"
import { searchProducts, type SearchFilters } from "@/lib/search"
import { useTranslation } from "@/lib/translations"

function SearchContent() {
  const searchParams = useSearchParams()
  const { t } = useTranslation()
  const [searchQuery, setSearchQuery] = useState(searchParams.get("q") || "")
  const [filters, setFilters] = useState<SearchFilters>({})
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid")
  const [isLoading, setIsLoading] = useState(false)

  // Perform search
  const searchResults = searchProducts(searchQuery, filters)

  useEffect(() => {
    const query = searchParams.get("q")
    if (query) {
      setSearchQuery(query)
    }
  }, [searchParams])

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)
    // Simulate search delay
    setTimeout(() => setIsLoading(false), 500)
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Search Header */}
      <div className="border-b bg-white">
        <div className="container mx-auto px-4 py-6">
          <form onSubmit={handleSearch} className="flex gap-4 mb-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
              <Input
                type="text"
                placeholder={t("searchPlaceholder")}
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>
            <Button type="submit" disabled={isLoading}>
              {isLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Search className="h-4 w-4" />}
            </Button>
          </form>

          {/* Search Results Summary */}
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-eco-dark-green">
                {searchQuery ? `Search Results for "${searchQuery}"` : "All Products"}
              </h1>
              <p className="text-muted-foreground">{searchResults.totalCount} products found</p>
            </div>

            {/* View Toggle */}
            <div className="hidden md:flex items-center gap-2">
              <Button
                variant={viewMode === "grid" ? "default" : "outline"}
                size="sm"
                onClick={() => setViewMode("grid")}
              >
                <Grid className="h-4 w-4" />
              </Button>
              <Button
                variant={viewMode === "list" ? "default" : "outline"}
                size="sm"
                onClick={() => setViewMode("list")}
              >
                <List className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="container mx-auto px-4 py-6">
        <div className="flex gap-6">
          {/* Filters Sidebar */}
          <aside className="w-full md:w-80 flex-shrink-0">
            <SearchFiltersComponent
              filters={filters}
              onFiltersChange={setFilters}
              availableCategories={searchResults.filters.categories}
              priceRange={searchResults.filters.priceRange}
            />
          </aside>

          {/* Results */}
          <main className="flex-1">
            {isLoading ? (
              <div className="flex items-center justify-center py-12">
                <Loader2 className="h-8 w-8 animate-spin text-eco-green" />
              </div>
            ) : searchResults.totalCount === 0 ? (
              <Card>
                <CardContent className="py-12 text-center">
                  <div className="text-muted-foreground mb-4">
                    <Search className="h-12 w-12 mx-auto mb-4 opacity-50" />
                    <h3 className="text-lg font-semibold mb-2">No products found</h3>
                    <p>Try adjusting your search terms or filters</p>
                  </div>
                  <Button
                    variant="outline"
                    onClick={() => {
                      setSearchQuery("")
                      setFilters({})
                    }}
                  >
                    Clear Search
                  </Button>
                </CardContent>
              </Card>
            ) : (
              <div
                className={`grid gap-6 ${
                  viewMode === "grid" ? "grid-cols-1 sm:grid-cols-2 lg:grid-cols-3" : "grid-cols-1"
                }`}
              >
                {searchResults.products.map((product) => (
                  <ProductCard key={product.id} product={product} className={viewMode === "list" ? "flex-row" : ""} />
                ))}
              </div>
            )}

            {/* Load More */}
            {searchResults.totalCount > 20 && (
              <div className="text-center mt-8">
                <Button variant="outline">Load More Products</Button>
              </div>
            )}
          </main>
        </div>
      </div>
    </div>
  )
}

export default function SearchPage() {
  return (
    <Suspense
      fallback={
        <div className="flex items-center justify-center min-h-screen">
          <Loader2 className="h-8 w-8 animate-spin text-eco-green" />
        </div>
      }
    >
      <SearchContent />
    </Suspense>
  )
}
