import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent } from "@/components/ui/card"
import { Separator } from "@/components/ui/separator"
import { Star, Heart, ShoppingCart, Truck, Shield, Leaf, Award } from "lucide-react"
import Image from "next/image"
import Link from "next/link"
import { getProductById } from "@/lib/products"
import { notFound } from "next/navigation"

interface ProductPageProps {
  params: {
    id: string
  }
}

export default function ProductPage({ params }: ProductPageProps) {
  const product = getProductById(params.id)

  if (!product) {
    notFound()
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Header />

      <main className="flex-1 py-8">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Product Images */}
            <div className="space-y-4">
              <div className="relative">
                <Image
                  src={product.images[0] || "/placeholder.svg?height=500&width=500"}
                  alt={product.name}
                  width={500}
                  height={500}
                  className="w-full h-96 object-cover rounded-lg"
                />
                <Button variant="ghost" size="sm" className="absolute top-4 right-4 bg-white/80 hover:bg-white">
                  <Heart className="h-4 w-4" />
                </Button>
              </div>
            </div>

            {/* Product Info */}
            <div className="space-y-6">
              <div>
                <h1 className="text-3xl font-bold mb-2">{product.name}</h1>
                <div className="flex items-center space-x-4 mb-4">
                  <div className="flex items-center">
                    <Star className="h-5 w-5 fill-yellow-400 text-yellow-400" />
                    <span className="font-medium ml-1">{product.rating}</span>
                    <span className="text-muted-foreground ml-1">({product.totalReviews} reviews)</span>
                  </div>
                  <Badge variant="outline" className={product.inStock ? "text-green-600" : "text-red-600"}>
                    {product.inStock ? "In Stock" : "Out of Stock"}
                  </Badge>
                </div>
              </div>

              {/* Price */}
              <div className="flex items-center space-x-3">
                <span className="text-3xl font-bold text-primary">${product.price}</span>
                {product.originalPrice && (
                  <>
                    <span className="text-xl text-muted-foreground line-through">${product.originalPrice}</span>
                    <Badge className="bg-red-500">
                      {Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100)}% OFF
                    </Badge>
                  </>
                )}
              </div>

              {/* Seller Info */}
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <Link href={`/seller/${product.seller.id}`}>
                        <h3 className="font-semibold hover:text-primary transition-colors">
                          {product.seller.businessName}
                        </h3>
                      </Link>
                      <div className="flex items-center space-x-1 text-sm text-muted-foreground">
                        <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                        <span>{product.seller.rating}</span>
                        <span>({product.seller.totalReviews} reviews)</span>
                      </div>
                      <p className="text-sm text-muted-foreground">{product.seller.location}</p>
                    </div>
                    <Button variant="outline" size="sm">
                      View Store
                    </Button>
                  </div>
                </CardContent>
              </Card>

              {/* Eco Features */}
              {product.ecoFeatures.length > 0 && (
                <div className="space-y-2">
                  <h3 className="font-semibold flex items-center">
                    <Leaf className="h-5 w-5 text-green-600 mr-2" />
                    Eco-Friendly Features
                  </h3>
                  <div className="flex flex-wrap gap-2">
                    {product.ecoFeatures.map((feature, index) => (
                      <Badge key={index} variant="outline" className="text-green-700 border-green-200">
                        {feature}
                      </Badge>
                    ))}
                  </div>
                </div>
              )}

              {/* Certifications */}
              {product.certifications.length > 0 && (
                <div className="space-y-2">
                  <h3 className="font-semibold flex items-center">
                    <Award className="h-5 w-5 text-blue-600 mr-2" />
                    Certifications
                  </h3>
                  <div className="flex flex-wrap gap-2">
                    {product.certifications.map((cert, index) => (
                      <Badge key={index} variant="outline" className="text-blue-700 border-blue-200">
                        {cert}
                      </Badge>
                    ))}
                  </div>
                </div>
              )}

              {/* Add to Cart */}
              <div className="space-y-4">
                <Button size="lg" className="w-full" disabled={!product.inStock}>
                  <ShoppingCart className="h-5 w-5 mr-2" />
                  Add to Cart
                </Button>
                <Button variant="outline" size="lg" className="w-full bg-transparent">
                  Buy Now
                </Button>
              </div>

              {/* Shipping Info */}
              <Card>
                <CardContent className="p-4 space-y-3">
                  <div className="flex items-center space-x-3">
                    <Truck className="h-5 w-5 text-primary" />
                    <div>
                      <p className="font-medium">
                        {product.shippingInfo.freeShipping ? "Free Shipping" : "Standard Shipping"}
                      </p>
                      <p className="text-sm text-muted-foreground">
                        Estimated delivery: {product.shippingInfo.estimatedDays} days
                      </p>
                    </div>
                  </div>
                  {product.shippingInfo.carbonNeutral && (
                    <div className="flex items-center space-x-3">
                      <Leaf className="h-5 w-5 text-green-600" />
                      <div>
                        <p className="font-medium">Carbon Neutral Shipping</p>
                        <p className="text-sm text-muted-foreground">We offset the carbon footprint of this delivery</p>
                      </div>
                    </div>
                  )}
                  <div className="flex items-center space-x-3">
                    <Shield className="h-5 w-5 text-blue-600" />
                    <div>
                      <p className="font-medium">Secure Payment</p>
                      <p className="text-sm text-muted-foreground">Your payment information is protected</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          <Separator className="my-8" />

          {/* Product Description */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2 space-y-6">
              <div>
                <h2 className="text-2xl font-bold mb-4">Product Description</h2>
                <p className="text-muted-foreground leading-relaxed">{product.description}</p>
              </div>

              {/* Materials */}
              {product.materials.length > 0 && (
                <div>
                  <h3 className="text-lg font-semibold mb-2">Materials</h3>
                  <ul className="list-disc list-inside space-y-1 text-muted-foreground">
                    {product.materials.map((material, index) => (
                      <li key={index}>{material}</li>
                    ))}
                  </ul>
                </div>
              )}
            </div>

            <div className="space-y-6">
              <Card>
                <CardContent className="p-4">
                  <h3 className="font-semibold mb-3">Product Details</h3>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Category:</span>
                      <span className="capitalize">{product.category.replace("-", " ")}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Stock:</span>
                      <span>{product.stockCount} available</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">SKU:</span>
                      <span>{product.id.toUpperCase()}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
