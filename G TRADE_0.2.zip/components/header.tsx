"use client"

import type React from "react"

import { Search, User, Heart, LogOut } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import Image from "next/image"
import Link from "next/link"
import { useState } from "react"
import { useRouter } from "next/navigation"
import { useAuth } from "@/lib/auth"
import { useCart } from "@/lib/cart"
import { useLanguage } from "@/lib/translations"
import { CartSidebar } from "@/components/cart/cart-sidebar"
import { LanguageSwitcher } from "@/components/language-switcher"
import { WalletWidget } from "@/components/ecoins/wallet-widget"
import { MobileNav } from "@/components/mobile/mobile-nav"

export function Header() {
  const { user, isAuthenticated, logout } = useAuth()
  const { wishlist } = useCart()
  const { t } = useLanguage()
  const [searchQuery, setSearchQuery] = useState("")
  const router = useRouter()

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    if (searchQuery.trim()) {
      router.push(`/search?q=${encodeURIComponent(searchQuery.trim())}`)
    } else {
      router.push("/search")
    }
  }

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container mx-auto px-4">
        <div className="flex h-14 sm:h-16 items-center justify-between gap-2">
          {/* Logo - Always visible and prominent on mobile */}
          <Link href="/" className="flex items-center space-x-2 flex-shrink-0 min-w-fit">
            <Image
              src="/gtrade-logo.png"
              alt="G TRADE Logo"
              width={36}
              height={36}
              className="rounded-lg sm:w-10 sm:h-10"
              priority
            />
            <span className="text-base sm:text-lg md:text-xl font-bold text-primary truncate">{t("siteName")}</span>
          </Link>

          {/* Search Bar - Hidden on mobile */}
          <div className="hidden md:flex flex-1 max-w-xl mx-8">
            <form onSubmit={handleSearch} className="relative w-full">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
              <Input
                placeholder={t("searchPlaceholder")}
                className="pl-10 pr-4"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </form>
          </div>

          {/* Navigation Actions - Reduced spacing on mobile */}
          <div className="flex items-center space-x-1 sm:space-x-2 md:space-x-4 flex-shrink-0">
            {/* Language Switcher - Hidden on very small screens */}
            <div className="hidden sm:block">
              <LanguageSwitcher />
            </div>

            {/* E-Coins Wallet - Desktop only */}
            {isAuthenticated && user?.role === "buyer" && (
              <div className="hidden lg:block">
                <WalletWidget />
              </div>
            )}

            {/* Wishlist - Desktop only */}
            <div className="hidden md:block">
              <Link href="/dashboard/buyer?tab=wishlist">
                <Button variant="ghost" size="sm" className="relative">
                  <Heart className="h-5 w-5" />
                  {wishlist.length > 0 && (
                    <Badge className="absolute -top-2 -right-2 h-5 w-5 rounded-full p-0 flex items-center justify-center text-xs">
                      {wishlist.length}
                    </Badge>
                  )}
                </Button>
              </Link>
            </div>

            {/* Cart - Desktop only */}
            <div className="hidden md:block">
              <CartSidebar />
            </div>

            {/* User Menu - Smaller on mobile */}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="sm" className="p-1.5 sm:p-2">
                  {isAuthenticated ? (
                    <Avatar className="h-7 w-7 sm:h-8 sm:w-8">
                      <AvatarImage src={user?.avatar || "/placeholder.svg"} />
                      <AvatarFallback className="text-xs">{user?.name?.charAt(0).toUpperCase()}</AvatarFallback>
                    </Avatar>
                  ) : (
                    <User className="h-5 w-5" />
                  )}
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                {isAuthenticated ? (
                  <>
                    <DropdownMenuItem>
                      <Link href={`/dashboard/${user?.role}`}>{t("dashboard")}</Link>
                    </DropdownMenuItem>
                    <DropdownMenuItem>
                      <Link href="/profile">{t("profile")}</Link>
                    </DropdownMenuItem>
                    <DropdownMenuItem>
                      <Link href="/orders">{t("myOrders")}</Link>
                    </DropdownMenuItem>
                    {user?.role === "seller" && (
                      <DropdownMenuItem>
                        <Link href="/seller/products">{t("myProducts")}</Link>
                      </DropdownMenuItem>
                    )}
                    {user?.role === "buyer" && (
                      <DropdownMenuItem>
                        <Link href="/dashboard/buyer?tab=wallet">{t("wallet")}</Link>
                      </DropdownMenuItem>
                    )}
                    <DropdownMenuSeparator />
                    <DropdownMenuItem onClick={logout} className="text-red-600">
                      <LogOut className="mr-2 h-4 w-4" />
                      {t("logout")}
                    </DropdownMenuItem>
                  </>
                ) : (
                  <>
                    <DropdownMenuItem>
                      <Link href="/login">{t("login")}</Link>
                    </DropdownMenuItem>
                    <DropdownMenuItem>
                      <Link href="/signup">{t("signup")}</Link>
                    </DropdownMenuItem>
                    <DropdownMenuItem>
                      <Link href="/signup">{t("becomeSeller")}</Link>
                    </DropdownMenuItem>
                  </>
                )}
              </DropdownMenuContent>
            </DropdownMenu>

            {/* Mobile Menu - Smaller button */}
            <div className="md:hidden">
              <MobileNav />
            </div>
          </div>
        </div>
      </div>
    </header>
  )
}
