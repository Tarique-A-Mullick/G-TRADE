"use client"

import { Leaf, Droplets, TreePine, Recycle } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { useLanguage } from "@/lib/translations"

interface EcoImpactDisplayProps {
  carbonSaved: number
  plasticReduced: number
  treesPlanted: number
  waterSaved: number
  showProgress?: boolean
}

export function EcoImpactDisplay({
  carbonSaved,
  plasticReduced,
  treesPlanted,
  waterSaved,
  showProgress = false,
}: EcoImpactDisplayProps) {
  const { t } = useLanguage()

  const impacts = [
    {
      icon: Leaf,
      label: t("carbonSaved"),
      value: carbonSaved,
      unit: "kg CO₂",
      color: "text-green-600",
      progress: showProgress ? Math.min((carbonSaved / 100) * 100, 100) : undefined,
    },
    {
      icon: Recycle,
      label: t("plasticReduced"),
      value: plasticReduced,
      unit: "g",
      color: "text-blue-600",
      progress: showProgress ? Math.min((plasticReduced / 1000) * 100, 100) : undefined,
    },
    {
      icon: TreePine,
      label: t("treesPlanted"),
      value: treesPlanted,
      unit: "",
      color: "text-emerald-600",
      progress: showProgress ? Math.min((treesPlanted / 10) * 100, 100) : undefined,
    },
    {
      icon: Droplets,
      label: "Water Saved",
      value: waterSaved,
      unit: "L",
      color: "text-cyan-600",
      progress: showProgress ? Math.min((waterSaved / 500) * 100, 100) : undefined,
    },
  ]

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-green-700">
          <Leaf className="h-5 w-5" />
          {t("ecoImpact")}
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-2 gap-4">
          {impacts.map((impact, index) => (
            <div key={index} className="space-y-2">
              <div className="flex items-center gap-2">
                <impact.icon className={`h-4 w-4 ${impact.color}`} />
                <span className="text-sm font-medium">{impact.label}</span>
              </div>
              <div className="text-lg font-bold">
                {impact.value}
                {impact.unit}
              </div>
              {impact.progress !== undefined && <Progress value={impact.progress} className="h-2" />}
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
