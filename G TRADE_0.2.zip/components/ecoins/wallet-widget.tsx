"use client"

import { Coins, Leaf, TrendingUp } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { useECoins } from "@/lib/ecoins"
import { useLanguage } from "@/lib/translations"

export function WalletWidget() {
  const { balance, getEcoImpact } = useECoins()
  const { t } = useLanguage()
  const ecoImpact = getEcoImpact()

  return (
    <Card className="bg-gradient-to-r from-green-50 to-emerald-50 border-green-200">
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2 text-green-700">
          <Coins className="h-5 w-5" />
          {t("wallet")}
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex items-center justify-between">
          <span className="text-sm text-muted-foreground">{t("balance")}</span>
          <Badge variant="secondary" className="bg-green-100 text-green-700 text-lg px-3 py-1">
            {balance} {t("eCoins")}
          </Badge>
        </div>

        <div className="grid grid-cols-2 gap-3 text-xs">
          <div className="flex items-center gap-1">
            <Leaf className="h-3 w-3 text-green-600" />
            <span>
              {ecoImpact.carbonSaved}kg {t("carbonSaved")}
            </span>
          </div>
          <div className="flex items-center gap-1">
            <TrendingUp className="h-3 w-3 text-blue-600" />
            <span>
              {ecoImpact.treesPlanted} {t("treesPlanted")}
            </span>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
