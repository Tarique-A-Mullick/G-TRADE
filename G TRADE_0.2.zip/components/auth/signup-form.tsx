"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Textarea } from "@/components/ui/textarea"
import { Loader2, Mail, Lock, User, Building, Phone, FileText } from "lucide-react"
import { useAuth } from "@/lib/auth"
import { useRouter } from "next/navigation"
import Link from "next/link"

export function SignupForm() {
  const [buyerData, setBuyerData] = useState({
    name: "",
    email: "",
    password: "",
    confirmPassword: "",
  })

  const [sellerData, setSellerData] = useState({
    name: "",
    email: "",
    password: "",
    confirmPassword: "",
    businessName: "",
    gst: "",
    address: "",
    phone: "",
  })

  const [loading, setLoading] = useState(false)
  const [error, setError] = useState("")
  const { signup } = useAuth()
  const router = useRouter()

  const handleSignup = async (role: "buyer" | "seller") => {
    setLoading(true)
    setError("")

    const data = role === "buyer" ? buyerData : sellerData

    // Validation
    if (!data.name || !data.email || !data.password) {
      setError("Please fill in all required fields")
      setLoading(false)
      return
    }

    if (data.password !== data.confirmPassword) {
      setError("Passwords do not match")
      setLoading(false)
      return
    }

    if (data.password.length < 6) {
      setError("Password must be at least 6 characters")
      setLoading(false)
      return
    }

    if (role === "seller" && !sellerData.businessName) {
      setError("Business name is required for sellers")
      setLoading(false)
      return
    }

    try {
      const success = await signup({
        ...data,
        role,
        ...(role === "seller" && {
          businessName: sellerData.businessName,
          gst: sellerData.gst,
          address: sellerData.address,
          phone: sellerData.phone,
        }),
      })

      if (success) {
        router.push(role === "buyer" ? "/dashboard/buyer" : "/dashboard/seller")
      } else {
        setError("Signup failed. Please try again.")
      }
    } catch (err) {
      setError("Signup failed. Please try again.")
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="max-w-md mx-auto">
      <Card>
        <CardHeader className="text-center">
          <CardTitle className="text-2xl">Join EcoMarket</CardTitle>
          <CardDescription>Create your account and start shopping sustainably</CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="buyer" className="w-full">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="buyer">Buyer</TabsTrigger>
              <TabsTrigger value="seller">Seller</TabsTrigger>
            </TabsList>

            <TabsContent value="buyer" className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="buyer-name">Full Name *</Label>
                <div className="relative">
                  <User className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
                  <Input
                    id="buyer-name"
                    placeholder="Enter your full name"
                    className="pl-10"
                    value={buyerData.name}
                    onChange={(e) => setBuyerData({ ...buyerData, name: e.target.value })}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="buyer-email">Email *</Label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
                  <Input
                    id="buyer-email"
                    type="email"
                    placeholder="Enter your email"
                    className="pl-10"
                    value={buyerData.email}
                    onChange={(e) => setBuyerData({ ...buyerData, email: e.target.value })}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="buyer-password">Password *</Label>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
                  <Input
                    id="buyer-password"
                    type="password"
                    placeholder="Create a password"
                    className="pl-10"
                    value={buyerData.password}
                    onChange={(e) => setBuyerData({ ...buyerData, password: e.target.value })}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="buyer-confirm">Confirm Password *</Label>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
                  <Input
                    id="buyer-confirm"
                    type="password"
                    placeholder="Confirm your password"
                    className="pl-10"
                    value={buyerData.confirmPassword}
                    onChange={(e) => setBuyerData({ ...buyerData, confirmPassword: e.target.value })}
                  />
                </div>
              </div>

              <Button className="w-full" onClick={() => handleSignup("buyer")} disabled={loading}>
                {loading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
                Create Buyer Account
              </Button>
            </TabsContent>

            <TabsContent value="seller" className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="seller-name">Full Name *</Label>
                  <div className="relative">
                    <User className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
                    <Input
                      id="seller-name"
                      placeholder="Your name"
                      className="pl-10"
                      value={sellerData.name}
                      onChange={(e) => setSellerData({ ...sellerData, name: e.target.value })}
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="seller-business">Business Name *</Label>
                  <div className="relative">
                    <Building className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
                    <Input
                      id="seller-business"
                      placeholder="Business name"
                      className="pl-10"
                      value={sellerData.businessName}
                      onChange={(e) => setSellerData({ ...sellerData, businessName: e.target.value })}
                    />
                  </div>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="seller-email">Business Email *</Label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
                  <Input
                    id="seller-email"
                    type="email"
                    placeholder="business@example.com"
                    className="pl-10"
                    value={sellerData.email}
                    onChange={(e) => setSellerData({ ...sellerData, email: e.target.value })}
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="seller-phone">Phone</Label>
                  <div className="relative">
                    <Phone className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
                    <Input
                      id="seller-phone"
                      placeholder="Phone number"
                      className="pl-10"
                      value={sellerData.phone}
                      onChange={(e) => setSellerData({ ...sellerData, phone: e.target.value })}
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="seller-gst">GST Number</Label>
                  <div className="relative">
                    <FileText className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
                    <Input
                      id="seller-gst"
                      placeholder="Optional"
                      className="pl-10"
                      value={sellerData.gst}
                      onChange={(e) => setSellerData({ ...sellerData, gst: e.target.value })}
                    />
                  </div>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="seller-address">Business Address</Label>
                <Textarea
                  id="seller-address"
                  placeholder="Enter your business address"
                  value={sellerData.address}
                  onChange={(e) => setSellerData({ ...sellerData, address: e.target.value })}
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="seller-password">Password *</Label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
                    <Input
                      id="seller-password"
                      type="password"
                      placeholder="Create password"
                      className="pl-10"
                      value={sellerData.password}
                      onChange={(e) => setSellerData({ ...sellerData, password: e.target.value })}
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="seller-confirm">Confirm *</Label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
                    <Input
                      id="seller-confirm"
                      type="password"
                      placeholder="Confirm"
                      className="pl-10"
                      value={sellerData.confirmPassword}
                      onChange={(e) => setSellerData({ ...sellerData, confirmPassword: e.target.value })}
                    />
                  </div>
                </div>
              </div>

              <Button className="w-full" onClick={() => handleSignup("seller")} disabled={loading}>
                {loading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
                Create Seller Account
              </Button>
            </TabsContent>
          </Tabs>

          {error && (
            <Alert className="mt-4">
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}

          <div className="mt-6 text-center">
            <div className="text-sm text-muted-foreground">
              Already have an account?{" "}
              <Link href="/login" className="text-primary hover:underline">
                Sign in here
              </Link>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
