"use client"

import { Shield, AlertCircle } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import type { AIVerification } from "@/lib/ecoins"
import { useLanguage } from "@/lib/translations"

interface AIVerificationBadgeProps {
  verification: AIVerification
  size?: "sm" | "md" | "lg"
}

export function AIVerificationBadge({ verification, size = "md" }: AIVerificationBadgeProps) {
  const { t } = useLanguage()

  const iconSize = size === "sm" ? "h-3 w-3" : size === "lg" ? "h-5 w-5" : "h-4 w-4"
  const badgeSize = size === "sm" ? "text-xs" : size === "lg" ? "text-sm" : "text-xs"

  if (!verification.isVerified) {
    return (
      <TooltipProvider>
        <Tooltip>
          <TooltipTrigger>
            <Badge variant="secondary" className={`${badgeSize} bg-gray-100 text-gray-600`}>
              <AlertCircle className={`${iconSize} mr-1`} />
              Pending Verification
            </Badge>
          </TooltipTrigger>
          <TooltipContent>
            <p>AI verification in progress</p>
          </TooltipContent>
        </Tooltip>
      </TooltipProvider>
    )
  }

  return (
    <TooltipProvider>
      <Tooltip>
        <TooltipTrigger>
          <Badge variant="secondary" className={`${badgeSize} bg-green-100 text-green-700`}>
            <Shield className={`${iconSize} mr-1`} />
            {t("aiVerified")}
          </Badge>
        </TooltipTrigger>
        <TooltipContent>
          <div className="space-y-1">
            <p className="font-semibold">AI Verification: {verification.confidence}% confidence</p>
            <p>Verified claims: {verification.claims.join(", ")}</p>
            <p>Certifications: {verification.certifications.join(", ")}</p>
          </div>
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  )
}
