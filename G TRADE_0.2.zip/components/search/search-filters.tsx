"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Checkbox } from "@/components/ui/checkbox"
import { Label } from "@/components/ui/label"
import { Slider } from "@/components/ui/slider"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { X, Filter } from "lucide-react"
import type { SearchFilters } from "@/lib/search"

interface SearchFiltersProps {
  filters: SearchFilters
  onFiltersChange: (filters: SearchFilters) => void
  availableCategories: { name: string; count: number }[]
  priceRange: [number, number]
  className?: string
}

export function SearchFiltersComponent({
  filters,
  onFiltersChange,
  availableCategories,
  priceRange,
  className = "",
}: SearchFiltersProps) {
  const [isOpen, setIsOpen] = useState(false)

  const updateFilter = (key: keyof SearchFilters, value: any) => {
    onFiltersChange({ ...filters, [key]: value })
  }

  const clearFilters = () => {
    onFiltersChange({})
  }

  const activeFiltersCount = Object.keys(filters).filter(
    (key) => filters[key as keyof SearchFilters] !== undefined && filters[key as keyof SearchFilters] !== "",
  ).length

  return (
    <div className={className}>
      {/* Mobile Filter Toggle */}
      <div className="md:hidden mb-4">
        <Button variant="outline" onClick={() => setIsOpen(!isOpen)} className="w-full justify-between">
          <div className="flex items-center gap-2">
            <Filter className="h-4 w-4" />
            Filters
            {activeFiltersCount > 0 && (
              <Badge variant="secondary" className="ml-2">
                {activeFiltersCount}
              </Badge>
            )}
          </div>
        </Button>
      </div>

      {/* Filter Panel */}
      <div className={`space-y-6 ${isOpen ? "block" : "hidden md:block"}`}>
        {/* Active Filters */}
        {activeFiltersCount > 0 && (
          <Card>
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="text-sm">Active Filters</CardTitle>
                <Button variant="ghost" size="sm" onClick={clearFilters}>
                  Clear All
                </Button>
              </div>
            </CardHeader>
            <CardContent className="pt-0">
              <div className="flex flex-wrap gap-2">
                {filters.category && (
                  <Badge variant="secondary" className="flex items-center gap-1">
                    {filters.category}
                    <X className="h-3 w-3 cursor-pointer" onClick={() => updateFilter("category", undefined)} />
                  </Badge>
                )}
                {filters.ecoVerified && (
                  <Badge variant="secondary" className="flex items-center gap-1">
                    Eco Verified
                    <X className="h-3 w-3 cursor-pointer" onClick={() => updateFilter("ecoVerified", undefined)} />
                  </Badge>
                )}
                {filters.rating && (
                  <Badge variant="secondary" className="flex items-center gap-1">
                    {filters.rating}+ Stars
                    <X className="h-3 w-3 cursor-pointer" onClick={() => updateFilter("rating", undefined)} />
                  </Badge>
                )}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Sort By */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm">Sort By</CardTitle>
          </CardHeader>
          <CardContent className="pt-0">
            <Select value={filters.sortBy || "relevance"} onValueChange={(value) => updateFilter("sortBy", value)}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="relevance">Relevance</SelectItem>
                <SelectItem value="price-low">Price: Low to High</SelectItem>
                <SelectItem value="price-high">Price: High to Low</SelectItem>
                <SelectItem value="rating">Customer Rating</SelectItem>
                <SelectItem value="newest">Newest First</SelectItem>
              </SelectContent>
            </Select>
          </CardContent>
        </Card>

        {/* Categories */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm">Categories</CardTitle>
          </CardHeader>
          <CardContent className="pt-0">
            <div className="space-y-3">
              {availableCategories.map((category) => (
                <div key={category.name} className="flex items-center justify-between">
                  <Label
                    htmlFor={`category-${category.name}`}
                    className="flex items-center gap-2 cursor-pointer flex-1"
                  >
                    <Checkbox
                      id={`category-${category.name}`}
                      checked={filters.category === category.name}
                      onCheckedChange={(checked) => updateFilter("category", checked ? category.name : undefined)}
                    />
                    <span className="text-sm">{category.name}</span>
                  </Label>
                  <span className="text-xs text-muted-foreground">({category.count})</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Price Range */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm">Price Range</CardTitle>
          </CardHeader>
          <CardContent className="pt-0">
            <div className="space-y-4">
              <Slider
                value={filters.priceRange || priceRange}
                onValueChange={(value) => updateFilter("priceRange", value as [number, number])}
                max={priceRange[1]}
                min={priceRange[0]}
                step={10}
                className="w-full"
              />
              <div className="flex justify-between text-sm text-muted-foreground">
                <span>₹{filters.priceRange?.[0] || priceRange[0]}</span>
                <span>₹{filters.priceRange?.[1] || priceRange[1]}</span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Rating */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm">Customer Rating</CardTitle>
          </CardHeader>
          <CardContent className="pt-0">
            <div className="space-y-2">
              {[4, 3, 2, 1].map((rating) => (
                <Label key={rating} htmlFor={`rating-${rating}`} className="flex items-center gap-2 cursor-pointer">
                  <Checkbox
                    id={`rating-${rating}`}
                    checked={filters.rating === rating}
                    onCheckedChange={(checked) => updateFilter("rating", checked ? rating : undefined)}
                  />
                  <span className="text-sm">{rating}+ Stars</span>
                </Label>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Eco Verified */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm">Sustainability</CardTitle>
          </CardHeader>
          <CardContent className="pt-0">
            <Label htmlFor="eco-verified" className="flex items-center gap-2 cursor-pointer">
              <Checkbox
                id="eco-verified"
                checked={filters.ecoVerified || false}
                onCheckedChange={(checked) => updateFilter("ecoVerified", checked || undefined)}
              />
              <span className="text-sm">Eco Verified Only</span>
            </Label>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
