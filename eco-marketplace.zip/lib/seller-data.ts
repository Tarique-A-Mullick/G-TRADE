export interface Order {
  id: string
  productId: string
  productName: string
  productImage: string
  buyerName: string
  buyerEmail: string
  quantity: number
  price: number
  total: number
  status: "pending" | "confirmed" | "shipped" | "delivered" | "cancelled"
  orderDate: string
  shippingAddress: {
    street: string
    city: string
    state: string
    zipCode: string
    country: string
  }
  trackingNumber?: string
}

export interface SalesData {
  totalEarnings: number
  monthlyEarnings: number
  totalOrders: number
  monthlyOrders: number
  totalProducts: number
  averageRating: number
  conversionRate: number
  topSellingProducts: {
    id: string
    name: string
    sales: number
    revenue: number
  }[]
}

export const mockOrders: Order[] = [
  {
    id: "ORD001",
    productId: "hg001",
    productName: "Bamboo Toothbrush Set (4 Pack)",
    productImage: "/products/bamboo-toothbrush.png",
    buyerName: "John Smith",
    buyerEmail: "john@example.com",
    quantity: 2,
    price: 12.99,
    total: 25.98,
    status: "shipped",
    orderDate: "2025-01-15",
    shippingAddress: {
      street: "123 Main St",
      city: "Portland",
      state: "OR",
      zipCode: "97201",
      country: "USA",
    },
    trackingNumber: "TRK123456789",
  },
  {
    id: "ORD002",
    productId: "hg002",
    productName: "Organic Cotton Bath Towels",
    productImage: "/products/organic-towels.png",
    buyerName: "Sarah Johnson",
    buyerEmail: "sarah@example.com",
    quantity: 1,
    price: 34.99,
    total: 34.99,
    status: "confirmed",
    orderDate: "2025-01-16",
    shippingAddress: {
      street: "456 Oak Ave",
      city: "Seattle",
      state: "WA",
      zipCode: "98101",
      country: "USA",
    },
  },
  {
    id: "ORD003",
    productId: "hg001",
    productName: "Bamboo Toothbrush Set (4 Pack)",
    productImage: "/products/bamboo-toothbrush.png",
    buyerName: "Mike Davis",
    buyerEmail: "mike@example.com",
    quantity: 3,
    price: 12.99,
    total: 38.97,
    status: "delivered",
    orderDate: "2025-01-10",
    shippingAddress: {
      street: "789 Pine St",
      city: "San Francisco",
      state: "CA",
      zipCode: "94102",
      country: "USA",
    },
    trackingNumber: "TRK987654321",
  },
]

export const mockSalesData: SalesData = {
  totalEarnings: 2450.67,
  monthlyEarnings: 567.89,
  totalOrders: 156,
  monthlyOrders: 23,
  totalProducts: 12,
  averageRating: 4.8,
  conversionRate: 3.2,
  topSellingProducts: [
    {
      id: "hg001",
      name: "Bamboo Toothbrush Set",
      sales: 45,
      revenue: 584.55,
    },
    {
      id: "hg002",
      name: "Organic Cotton Bath Towels",
      sales: 28,
      revenue: 979.72,
    },
    {
      id: "hg003",
      name: "Recycled Plastic Planters",
      sales: 22,
      revenue: 637.78,
    },
  ],
}

export function getOrdersBySeller(sellerId: string): Order[] {
  // In a real app, this would filter by seller ID
  return mockOrders
}

export function getSalesDataBySeller(sellerId: string): SalesData {
  // In a real app, this would fetch seller-specific data
  return mockSalesData
}
