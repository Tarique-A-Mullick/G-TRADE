import { create } from "zustand"
import { persist } from "zustand/middleware"

interface ECoinsState {
  balance: number
  totalEarned: number
  transactions: ECoinsTransaction[]
  addCoins: (amount: number, reason: string) => void
  redeemCoins: (amount: number, reason: string) => void
  getEcoImpact: () => EcoImpact
}

interface ECoinsTransaction {
  id: string
  amount: number
  type: "earned" | "redeemed"
  reason: string
  date: Date
}

interface EcoImpact {
  carbonSaved: number // kg CO2
  plasticReduced: number // grams
  treesPlanted: number
  waterSaved: number // liters
}

export const useECoins = create<ECoinsState>()(
  persist(
    (set, get) => ({
      balance: 0,
      totalEarned: 0,
      transactions: [],

      addCoins: (amount: number, reason: string) => {
        const transaction: ECoinsTransaction = {
          id: Date.now().toString(),
          amount,
          type: "earned",
          reason,
          date: new Date(),
        }

        set((state) => ({
          balance: state.balance + amount,
          totalEarned: state.totalEarned + amount,
          transactions: [transaction, ...state.transactions],
        }))
      },

      redeemCoins: (amount: number, reason: string) => {
        const state = get()
        if (state.balance >= amount) {
          const transaction: ECoinsTransaction = {
            id: Date.now().toString(),
            amount,
            type: "redeemed",
            reason,
            date: new Date(),
          }

          set((state) => ({
            balance: state.balance - amount,
            transactions: [transaction, ...state.transactions],
          }))
        }
      },

      getEcoImpact: () => {
        const state = get()
        // Calculate eco impact based on total coins earned
        const multiplier = state.totalEarned / 100

        return {
          carbonSaved: Math.round(multiplier * 2.5), // 2.5kg CO2 per 100 coins
          plasticReduced: Math.round(multiplier * 150), // 150g plastic per 100 coins
          treesPlanted: Math.round(multiplier * 0.1), // 0.1 trees per 100 coins
          waterSaved: Math.round(multiplier * 50), // 50L water per 100 coins
        }
      },
    }),
    {
      name: "ecoins-storage",
    },
  ),
)

// AI Verification System
export interface AIVerification {
  isVerified: boolean
  confidence: number
  claims: string[]
  verificationDate: Date
  certifications: string[]
}

export function verifyEcoFriendliness(product: any): AIVerification {
  // Placeholder AI verification logic
  const ecoKeywords = ["organic", "bamboo", "recycled", "sustainable", "biodegradable", "eco-friendly"]
  const claims = product.description.toLowerCase()

  const matchedKeywords = ecoKeywords.filter(
    (keyword) => claims.includes(keyword) || product.name.toLowerCase().includes(keyword),
  )

  const confidence = Math.min((matchedKeywords.length / ecoKeywords.length) * 100, 95)
  const isVerified = confidence > 60

  return {
    isVerified,
    confidence,
    claims: matchedKeywords,
    verificationDate: new Date(),
    certifications: isVerified ? ["Eco-Friendly Verified", "Sustainable Materials"] : [],
  }
}
