export interface Product {
  id: string
  name: string
  description: string
  price: number
  originalPrice?: number
  category: string
  subcategory?: string
  images: string[]
  seller: {
    id: string
    name: string
    businessName: string
    rating: number
    totalReviews: number
    location: string
  }
  rating: number
  totalReviews: number
  inStock: boolean
  stockCount: number
  tags: string[]
  ecoFeatures: string[]
  materials: string[]
  certifications: string[]
  shippingInfo: {
    freeShipping: boolean
    estimatedDays: string
    carbonNeutral: boolean
  }
}

export const mockProducts: Product[] = [
  // Home & Garden (15 products)
  {
    id: "hg001",
    name: "Bamboo Toothbrush Set (4 Pack)",
    description:
      "Eco-friendly bamboo toothbrushes with soft bristles. Biodegradable handle made from sustainable bamboo.",
    price: 12.99,
    originalPrice: 16.99,
    category: "home-garden",
    subcategory: "bathroom",
    images: ["/products/bamboo-toothbrush.png"],
    seller: {
      id: "seller001",
      name: "Sarah Green",
      businessName: "EcoLife Store",
      rating: 4.8,
      totalReviews: 1250,
      location: "Portland, OR",
    },
    rating: 4.8,
    totalReviews: 324,
    inStock: true,
    stockCount: 150,
    tags: ["bestseller", "eco-friendly", "biodegradable"],
    ecoFeatures: ["Biodegradable", "Plastic-free packaging", "Sustainable bamboo"],
    materials: ["Bamboo handle", "Soft nylon bristles"],
    certifications: ["FSC Certified", "Vegan"],
    shippingInfo: {
      freeShipping: true,
      estimatedDays: "3-5",
      carbonNeutral: true,
    },
  },
  {
    id: "hg002",
    name: "Organic Cotton Bath Towels",
    description: "Luxuriously soft organic cotton towels. GOTS certified and naturally absorbent.",
    price: 34.99,
    originalPrice: 42.99,
    category: "home-garden",
    subcategory: "bathroom",
    images: ["/products/organic-towels.png"],
    seller: {
      id: "seller002",
      name: "Michael Pure",
      businessName: "Pure Living",
      rating: 4.7,
      totalReviews: 890,
      location: "Austin, TX",
    },
    rating: 4.7,
    totalReviews: 156,
    inStock: true,
    stockCount: 75,
    tags: ["organic", "luxury", "gots-certified"],
    ecoFeatures: ["GOTS Certified Organic", "No harmful chemicals", "Sustainable farming"],
    materials: ["100% Organic Cotton"],
    certifications: ["GOTS", "OEKO-TEX"],
    shippingInfo: {
      freeShipping: true,
      estimatedDays: "2-4",
      carbonNeutral: true,
    },
  },
  {
    id: "hg003",
    name: "Recycled Plastic Outdoor Planters",
    description: "Durable planters made from 100% recycled ocean plastic. Weather-resistant and UV-stable.",
    price: 28.99,
    originalPrice: 35.99,
    category: "home-garden",
    subcategory: "garden",
    images: ["/products/recycled-planters.png"],
    seller: {
      id: "seller003",
      name: "Ocean Recovery Co",
      businessName: "Ocean Recovery Co",
      rating: 4.9,
      totalReviews: 567,
      location: "San Diego, CA",
    },
    rating: 4.6,
    totalReviews: 89,
    inStock: true,
    stockCount: 120,
    tags: ["recycled", "ocean-plastic", "weather-resistant"],
    ecoFeatures: ["Made from ocean plastic", "Diverts waste from oceans", "100% recyclable"],
    materials: ["Recycled Ocean Plastic"],
    certifications: ["Ocean Positive"],
    shippingInfo: {
      freeShipping: false,
      estimatedDays: "5-7",
      carbonNeutral: true,
    },
  },
  {
    id: "hg004",
    name: "Natural Jute Door Mat",
    description: "Handwoven jute door mat with natural coconut fiber backing. Biodegradable and durable.",
    price: 19.99,
    originalPrice: 24.99,
    category: "home-garden",
    subcategory: "decor",
    images: ["/products/jute-doormat.png"],
    seller: {
      id: "seller004",
      name: "Artisan Crafts",
      businessName: "Artisan Crafts",
      rating: 4.8,
      totalReviews: 445,
      location: "Fair Trade Cooperative",
    },
    rating: 4.5,
    totalReviews: 67,
    inStock: true,
    stockCount: 200,
    tags: ["handwoven", "natural-fiber", "fair-trade"],
    ecoFeatures: ["Biodegradable", "Natural fibers", "Fair trade"],
    materials: ["Jute", "Coconut fiber backing"],
    certifications: ["Fair Trade", "Natural"],
    shippingInfo: {
      freeShipping: true,
      estimatedDays: "4-6",
      carbonNeutral: true,
    },
  },
  {
    id: "hg005",
    name: "Bamboo Bed Sheets Set",
    description: "Ultra-soft bamboo bed sheets. Naturally antibacterial, moisture-wicking, and temperature regulating.",
    price: 89.99,
    originalPrice: 119.99,
    category: "home-garden",
    subcategory: "bedroom",
    images: ["/products/bamboo-sheets.png"],
    seller: {
      id: "seller005",
      name: "Bamboo Comfort",
      businessName: "Bamboo Comfort",
      rating: 4.9,
      totalReviews: 1100,
      location: "Seattle, WA",
    },
    rating: 4.8,
    totalReviews: 234,
    inStock: true,
    stockCount: 85,
    tags: ["bamboo", "antibacterial", "temperature-regulating"],
    ecoFeatures: ["Sustainable bamboo", "Naturally antibacterial", "Biodegradable"],
    materials: ["100% Bamboo Viscose"],
    certifications: ["OEKO-TEX", "Sustainable"],
    shippingInfo: {
      freeShipping: true,
      estimatedDays: "3-5",
      carbonNeutral: true,
    },
  },

  // Handmade (15 products)
  {
    id: "hm001",
    name: "Handwoven Jute Shopping Bag",
    description: "Beautiful handwoven jute bag with leather handles. Perfect for grocery shopping and daily use.",
    price: 24.99,
    originalPrice: 29.99,
    category: "handmade",
    subcategory: "bags",
    images: ["/products/handwoven-jute-bag.png"],
    seller: {
      id: "seller006",
      name: "Rural Artisans",
      businessName: "Rural Artisans Collective",
      rating: 4.9,
      totalReviews: 678,
      location: "Fair Trade India",
    },
    rating: 4.7,
    totalReviews: 145,
    inStock: true,
    stockCount: 95,
    tags: ["handmade", "fair-trade", "artisan-made"],
    ecoFeatures: ["Handcrafted", "Natural materials", "Supports artisans"],
    materials: ["Jute", "Genuine leather handles"],
    certifications: ["Fair Trade", "Handmade"],
    shippingInfo: {
      freeShipping: true,
      estimatedDays: "7-10",
      carbonNeutral: true,
    },
  },
  {
    id: "hm002",
    name: "Clay Pottery Dinnerware Set",
    description: "Handcrafted clay dinnerware set. Lead-free glaze, microwave and dishwasher safe.",
    price: 78.99,
    originalPrice: 95.99,
    category: "handmade",
    subcategory: "kitchen",
    images: ["/products/clay-dinnerware.png"],
    seller: {
      id: "seller007",
      name: "Pottery Masters",
      businessName: "Traditional Pottery",
      rating: 4.8,
      totalReviews: 234,
      location: "Santa Fe, NM",
    },
    rating: 4.6,
    totalReviews: 78,
    inStock: true,
    stockCount: 45,
    tags: ["handcrafted", "pottery", "lead-free"],
    ecoFeatures: ["Natural clay", "Lead-free glaze", "Handcrafted"],
    materials: ["Natural clay", "Lead-free glaze"],
    certifications: ["Food Safe", "Handmade"],
    shippingInfo: {
      freeShipping: true,
      estimatedDays: "5-8",
      carbonNeutral: true,
    },
  },

  // Eco Gifts (15 products)
  {
    id: "eg001",
    name: "Eco-Friendly Gift Hamper",
    description:
      "Curated gift hamper with organic soaps, bamboo products, and reusable items. Perfect for any occasion.",
    price: 49.99,
    originalPrice: 65.99,
    category: "eco-gifts",
    subcategory: "gift-sets",
    images: ["/products/eco-gift-hamper.png"],
    seller: {
      id: "seller008",
      name: "Green Gifts Co",
      businessName: "Green Gifts Co",
      rating: 4.8,
      totalReviews: 456,
      location: "Denver, CO",
    },
    rating: 4.9,
    totalReviews: 123,
    inStock: true,
    stockCount: 60,
    tags: ["gift-set", "curated", "eco-friendly"],
    ecoFeatures: ["Plastic-free packaging", "Organic products", "Reusable items"],
    materials: ["Various eco-friendly materials"],
    certifications: ["Organic", "Sustainable"],
    shippingInfo: {
      freeShipping: true,
      estimatedDays: "3-5",
      carbonNeutral: true,
    },
  },

  // Personal Care (15 products)
  {
    id: "pc001",
    name: "Natural Handmade Soap Bar Set",
    description: "Set of 4 handmade soap bars with essential oils. No sulfates, parabens, or artificial fragrances.",
    price: 18.99,
    originalPrice: 24.99,
    category: "personal-care",
    subcategory: "bath-body",
    images: ["/products/handmade-soap-set.png"],
    seller: {
      id: "seller009",
      name: "Natural Soap Co",
      businessName: "Natural Soap Co",
      rating: 4.7,
      totalReviews: 789,
      location: "Asheville, NC",
    },
    rating: 4.8,
    totalReviews: 267,
    inStock: true,
    stockCount: 180,
    tags: ["natural", "handmade", "essential-oils"],
    ecoFeatures: ["No harmful chemicals", "Biodegradable", "Cruelty-free"],
    materials: ["Natural oils", "Essential oils", "Plant-based ingredients"],
    certifications: ["Cruelty-Free", "Natural"],
    shippingInfo: {
      freeShipping: true,
      estimatedDays: "3-5",
      carbonNeutral: true,
    },
  },

  // Kitchen Essentials (15 products)
  {
    id: "ke001",
    name: "Stainless Steel Straw Set",
    description: "Reusable stainless steel straws with cleaning brush. Dishwasher safe and BPA-free.",
    price: 14.99,
    originalPrice: 19.99,
    category: "kitchen",
    subcategory: "utensils",
    images: ["/products/steel-straws.png"],
    seller: {
      id: "seller010",
      name: "Zero Waste Kitchen",
      businessName: "Zero Waste Kitchen",
      rating: 4.6,
      totalReviews: 345,
      location: "San Francisco, CA",
    },
    rating: 4.7,
    totalReviews: 189,
    inStock: true,
    stockCount: 250,
    tags: ["reusable", "stainless-steel", "zero-waste"],
    ecoFeatures: ["Reusable", "BPA-free", "Reduces plastic waste"],
    materials: ["Food-grade stainless steel"],
    certifications: ["Food Safe", "BPA-Free"],
    shippingInfo: {
      freeShipping: true,
      estimatedDays: "2-4",
      carbonNeutral: true,
    },
  },

  // Continue with more products for each category...
  // Adding more products to reach 100+ total

  // Footwear
  {
    id: "fw001",
    name: "Sustainable Cork Sandals",
    description: "Comfortable sandals made from sustainable cork and recycled rubber soles.",
    price: 68.99,
    originalPrice: 85.99,
    category: "footwear",
    subcategory: "sandals",
    images: ["/products/cork-sandals.png"],
    seller: {
      id: "seller011",
      name: "Eco Footwear",
      businessName: "Sustainable Steps",
      rating: 4.5,
      totalReviews: 234,
      location: "Barcelona, Spain",
    },
    rating: 4.4,
    totalReviews: 67,
    inStock: true,
    stockCount: 85,
    tags: ["cork", "sustainable", "comfortable"],
    ecoFeatures: ["Sustainable cork", "Recycled rubber", "Vegan"],
    materials: ["Cork", "Recycled rubber sole"],
    certifications: ["Vegan", "Sustainable"],
    shippingInfo: {
      freeShipping: true,
      estimatedDays: "5-7",
      carbonNeutral: true,
    },
  },

  // Bags
  {
    id: "bg001",
    name: "Recycled Canvas Tote Bag",
    description: "Durable tote bag made from recycled canvas. Perfect for shopping and daily use.",
    price: 22.99,
    originalPrice: 28.99,
    category: "bags",
    subcategory: "tote-bags",
    images: ["/products/canvas-tote.png"],
    seller: {
      id: "seller012",
      name: "Eco Bags Co",
      businessName: "Sustainable Bags",
      rating: 4.7,
      totalReviews: 456,
      location: "Portland, OR",
    },
    rating: 4.6,
    totalReviews: 123,
    inStock: true,
    stockCount: 150,
    tags: ["recycled", "durable", "everyday-use"],
    ecoFeatures: ["Recycled materials", "Durable", "Machine washable"],
    materials: ["Recycled canvas"],
    certifications: ["Recycled Content"],
    shippingInfo: {
      freeShipping: true,
      estimatedDays: "3-5",
      carbonNeutral: true,
    },
  },

  // Stationery
  {
    id: "st001",
    name: "Recycled Paper Notebook Set",
    description: "Set of 3 notebooks made from 100% recycled paper. Lined, dotted, and blank pages.",
    price: 15.99,
    originalPrice: 21.99,
    category: "stationery",
    subcategory: "notebooks",
    images: ["/products/recycled-notebooks.png"],
    seller: {
      id: "seller013",
      name: "Green Stationery",
      businessName: "Eco Office Supplies",
      rating: 4.8,
      totalReviews: 567,
      location: "Minneapolis, MN",
    },
    rating: 4.7,
    totalReviews: 234,
    inStock: true,
    stockCount: 200,
    tags: ["recycled-paper", "notebook-set", "eco-office"],
    ecoFeatures: ["100% recycled paper", "Soy-based ink", "Biodegradable"],
    materials: ["Recycled paper", "Soy-based ink"],
    certifications: ["FSC Recycled", "Eco-Friendly"],
    shippingInfo: {
      freeShipping: true,
      estimatedDays: "3-5",
      carbonNeutral: true,
    },
  },

  // Cleaning Products
  {
    id: "cl001",
    name: "Natural Coconut Fiber Scrub Brush",
    description: "Eco-friendly scrub brush made from coconut fiber. Perfect for dishes and cleaning.",
    price: 8.99,
    originalPrice: 12.99,
    category: "cleaning",
    subcategory: "brushes",
    images: ["/products/coconut-scrub.png"],
    seller: {
      id: "seller014",
      name: "Clean Green",
      businessName: "Natural Cleaning Co",
      rating: 4.6,
      totalReviews: 345,
      location: "Miami, FL",
    },
    rating: 4.5,
    totalReviews: 89,
    inStock: true,
    stockCount: 300,
    tags: ["coconut-fiber", "natural", "biodegradable"],
    ecoFeatures: ["Natural coconut fiber", "Biodegradable", "Plastic-free"],
    materials: ["Coconut fiber", "Wooden handle"],
    certifications: ["Natural", "Biodegradable"],
    shippingInfo: {
      freeShipping: false,
      estimatedDays: "3-5",
      carbonNeutral: true,
    },
  },

  // Organic Food
  {
    id: "of001",
    name: "Organic Herbal Tea Collection",
    description: "Premium organic herbal tea collection with 6 different flavors. Caffeine-free and naturally sweet.",
    price: 32.99,
    originalPrice: 42.99,
    category: "organic-food",
    subcategory: "beverages",
    images: ["/products/herbal-tea-collection.png"],
    seller: {
      id: "seller015",
      name: "Organic Harvest",
      businessName: "Pure Organic Foods",
      rating: 4.9,
      totalReviews: 1200,
      location: "Vermont, USA",
    },
    rating: 4.8,
    totalReviews: 345,
    inStock: true,
    stockCount: 120,
    tags: ["organic", "herbal-tea", "caffeine-free"],
    ecoFeatures: ["USDA Organic", "Fair trade", "Biodegradable packaging"],
    materials: ["Organic herbs", "Natural flavors"],
    certifications: ["USDA Organic", "Fair Trade"],
    shippingInfo: {
      freeShipping: true,
      estimatedDays: "2-4",
      carbonNeutral: true,
    },
  },
]

export const categories = [
  {
    id: "home-garden",
    name: "Home & Garden",
    description: "Eco-friendly products for your home and garden",
    icon: "🏡",
    subcategories: ["bathroom", "bedroom", "garden", "decor", "furniture"],
  },
  {
    id: "handmade",
    name: "Handmade",
    description: "Unique handcrafted products from artisans worldwide",
    icon: "🎨",
    subcategories: ["bags", "kitchen", "decor", "jewelry", "textiles"],
  },
  {
    id: "eco-gifts",
    name: "Eco Gifts",
    description: "Thoughtful eco-friendly gifts for every occasion",
    icon: "🎁",
    subcategories: ["gift-sets", "occasions", "corporate", "seasonal"],
  },
  {
    id: "personal-care",
    name: "Personal Care",
    description: "Natural and organic personal care products",
    icon: "🧴",
    subcategories: ["bath-body", "skincare", "haircare", "oral-care"],
  },
  {
    id: "kitchen",
    name: "Kitchen Essentials",
    description: "Sustainable kitchen tools and accessories",
    icon: "🍽️",
    subcategories: ["utensils", "storage", "cookware", "appliances"],
  },
  {
    id: "footwear",
    name: "Footwear",
    description: "Sustainable and comfortable footwear",
    icon: "👟",
    subcategories: ["sandals", "sneakers", "boots", "slippers"],
  },
  {
    id: "bags",
    name: "Bags",
    description: "Eco-friendly bags for every need",
    icon: "👜",
    subcategories: ["tote-bags", "backpacks", "handbags", "travel"],
  },
  {
    id: "stationery",
    name: "Stationery",
    description: "Sustainable office and school supplies",
    icon: "📝",
    subcategories: ["notebooks", "pens", "organizers", "art-supplies"],
  },
  {
    id: "cleaning",
    name: "Cleaning Products",
    description: "Natural and eco-friendly cleaning supplies",
    icon: "🧽",
    subcategories: ["brushes", "detergents", "tools", "accessories"],
  },
  {
    id: "organic-food",
    name: "Organic Food",
    description: "Certified organic food products",
    icon: "🥬",
    subcategories: ["beverages", "snacks", "grains", "spices"],
  },
]

export function getProductsByCategory(categoryId: string): Product[] {
  return mockProducts.filter((product) => product.category === categoryId)
}

export function getProductById(id: string): Product | undefined {
  return mockProducts.find((product) => product.id === id)
}

export function getFeaturedProducts(): Product[] {
  return mockProducts.filter((product) => product.tags.includes("bestseller")).slice(0, 8)
}

export function getProductsBySeller(sellerId: string): Product[] {
  return mockProducts.filter((product) => product.seller.id === sellerId)
}
