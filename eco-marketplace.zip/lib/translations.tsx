"use client"

export const translations = {
  en: {
    // Header & Navigation
    siteName: "G TRADE",
    searchPlaceholder: "Search for eco-friendly products...",
    categories: {
      "home-garden": "Home & Garden",
      handmade: "Handmade",
      "eco-gifts": "Eco Gifts",
      "personal-care": "Personal Care",
      kitchen: "Kitchen Essentials",
      footwear: "Footwear",
      bags: "Bags",
      stationery: "Stationery",
      cleaning: "Cleaning",
      "organic-food": "Organic Food",
    },
    // Common Actions
    login: "Login",
    signup: "Sign Up",
    logout: "Logout",
    dashboard: "Dashboard",
    profile: "Profile",
    myOrders: "My Orders",
    myProducts: "My Products",
    becomeSeller: "Become a Seller",
    // E-Coins & Wallet
    eCoins: "E-Coins",
    wallet: "Wallet",
    balance: "Balance",
    earnCoins: "Earn Coins",
    redeemCoins: "Redeem Coins",
    coinsEarned: "Coins Earned",
    // Eco Impact
    ecoImpact: "Eco Impact",
    carbonSaved: "CO₂ Saved",
    plasticReduced: "Plastic Reduced",
    treesPlanted: "Trees Planted",
    // AI Verification
    aiVerified: "AI Verified",
    ecoFriendly: "Eco-Friendly",
    verified: "Verified",
    // Mobile
    menu: "Menu",
    close: "Close",
    addToCart: "Add to Cart",
    buyNow: "Buy Now",
  },
  hi: {
    // Header & Navigation
    siteName: "जी ट्रेड",
    searchPlaceholder: "पर्यावरण-अनुकूल उत्पादों की खोज करें...",
    categories: {
      "home-garden": "घर और बगीचा",
      handmade: "हस्तनिर्मित",
      "eco-gifts": "पर्यावरण उपहार",
      "personal-care": "व्यक्तिगत देखभाल",
      kitchen: "रसोई आवश्यक",
      footwear: "जूते",
      bags: "बैग",
      stationery: "स्टेशनरी",
      cleaning: "सफाई",
      "organic-food": "जैविक भोजन",
    },
    // Common Actions
    login: "लॉगिन",
    signup: "साइन अप",
    logout: "लॉगआउट",
    dashboard: "डैशबोर्ड",
    profile: "प्रोफाइल",
    myOrders: "मेरे ऑर्डर",
    myProducts: "मेरे उत्पाद",
    becomeSeller: "विक्रेता बनें",
    // E-Coins & Wallet
    eCoins: "ई-कॉइन्स",
    wallet: "वॉलेट",
    balance: "बैलेंस",
    earnCoins: "कॉइन्स कमाएं",
    redeemCoins: "कॉइन्स रिडीम करें",
    coinsEarned: "कॉइन्स अर्जित",
    // Eco Impact
    ecoImpact: "पर्यावरण प्रभाव",
    carbonSaved: "CO₂ बचाया गया",
    plasticReduced: "प्लास्टिक कम किया",
    treesPlanted: "पेड़ लगाए गए",
    // AI Verification
    aiVerified: "AI सत्यापित",
    ecoFriendly: "पर्यावरण-अनुकूल",
    verified: "सत्यापित",
    // Mobile
    menu: "मेनू",
    close: "बंद करें",
    addToCart: "कार्ट में जोड़ें",
    buyNow: "अभी खरीदें",
  },
}

export type Language = keyof typeof translations
export type TranslationKey = keyof typeof translations.en

// Language context
import { createContext, useContext, useState, type ReactNode } from "react"

interface LanguageContextType {
  language: Language
  setLanguage: (lang: Language) => void
  t: (key: TranslationKey | string) => string
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined)

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [language, setLanguage] = useState<Language>("en")

  const t = (key: TranslationKey | string): string => {
    const keys = key.split(".")
    let value: any = translations[language]

    for (const k of keys) {
      value = value?.[k]
    }

    return value || key
  }

  return <LanguageContext.Provider value={{ language, setLanguage, t }}>{children}</LanguageContext.Provider>
}

export function useLanguage() {
  const context = useContext(LanguageContext)
  if (!context) {
    throw new Error("useLanguage must be used within a LanguageProvider")
  }
  return context
}
