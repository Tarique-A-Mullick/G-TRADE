import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { ProductCard } from "@/components/product-card"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Star, MapPin, Phone, Mail, Award } from "lucide-react"
import { getProductsBySeller } from "@/lib/products"
import { notFound } from "next/navigation"

interface SellerPageProps {
  params: {
    id: string
  }
}

export default function SellerPage({ params }: SellerPageProps) {
  const sellerProducts = getProductsBySeller(params.id)

  if (sellerProducts.length === 0) {
    notFound()
  }

  const seller = sellerProducts[0].seller

  return (
    <div className="min-h-screen flex flex-col">
      <Header />

      <main className="flex-1">
        {/* Seller Header */}
        <section className="bg-muted/30 py-12">
          <div className="container mx-auto px-4">
            <Card className="max-w-4xl mx-auto">
              <CardContent className="p-8">
                <div className="flex flex-col md:flex-row items-start md:items-center space-y-4 md:space-y-0 md:space-x-6">
                  <div className="w-24 h-24 bg-primary/10 rounded-full flex items-center justify-center">
                    <span className="text-2xl font-bold text-primary">{seller.businessName.charAt(0)}</span>
                  </div>

                  <div className="flex-1 space-y-3">
                    <div>
                      <h1 className="text-3xl font-bold">{seller.businessName}</h1>
                      <p className="text-muted-foreground">by {seller.name}</p>
                    </div>

                    <div className="flex items-center space-x-4">
                      <div className="flex items-center">
                        <Star className="h-5 w-5 fill-yellow-400 text-yellow-400" />
                        <span className="font-medium ml-1">{seller.rating}</span>
                        <span className="text-muted-foreground ml-1">({seller.totalReviews} reviews)</span>
                      </div>
                      <div className="flex items-center text-muted-foreground">
                        <MapPin className="h-4 w-4 mr-1" />
                        <span>{seller.location}</span>
                      </div>
                    </div>

                    <div className="flex flex-wrap gap-2">
                      <Badge variant="outline">
                        <Award className="h-3 w-3 mr-1" />
                        Verified Seller
                      </Badge>
                      <Badge variant="outline">{sellerProducts.length} Products</Badge>
                      <Badge variant="outline" className="text-green-600">
                        Eco-Friendly
                      </Badge>
                    </div>
                  </div>

                  <div className="flex flex-col space-y-2">
                    <Button>
                      <Mail className="h-4 w-4 mr-2" />
                      Contact Seller
                    </Button>
                    <Button variant="outline">
                      <Phone className="h-4 w-4 mr-2" />
                      Call Store
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </section>

        {/* Seller Products */}
        <section className="py-12">
          <div className="container mx-auto px-4">
            <div className="mb-8">
              <h2 className="text-2xl font-bold mb-2">Products from {seller.businessName}</h2>
              <p className="text-muted-foreground">Discover all the eco-friendly products from this verified seller</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 gap-6">
              {sellerProducts.map((product) => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  )
}
