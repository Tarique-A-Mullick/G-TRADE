import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Leaf, Recycle, Heart, Star, ShoppingBag, Users, Award, Truck } from "lucide-react"
import Image from "next/image"
import Link from "next/link"

export default function HomePage() {
  return (
    <div className="min-h-screen flex flex-col">
      <Header />

      <main className="flex-1">
        {/* Hero Section */}
        <section className="bg-gradient-to-r from-primary/10 to-accent/20 py-16">
          <div className="container mx-auto px-4 text-center">
            <div className="max-w-3xl mx-auto space-y-6">
              <h1 className="text-4xl md:text-6xl font-bold text-foreground">
                Shop <span className="text-primary">Sustainably</span>,
                <br />
                Live <span className="text-primary">Responsibly</span>
              </h1>
              <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                Discover thousands of eco-friendly and handmade products from verified sellers. Every purchase makes a
                positive impact on our planet.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button size="lg" className="text-lg px-8">
                  <ShoppingBag className="mr-2 h-5 w-5" />
                  Shop Now
                </Button>
                <Button variant="outline" size="lg" className="text-lg px-8 bg-transparent">
                  <Users className="mr-2 h-5 w-5" />
                  Become a Seller
                </Button>
              </div>
            </div>
          </div>
        </section>

        {/* Impact Stats */}
        <section className="py-12 bg-muted/30">
          <div className="container mx-auto px-4">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6 text-center">
              <div className="space-y-2">
                <div className="text-3xl font-bold text-primary">10K+</div>
                <div className="text-sm text-muted-foreground">Eco Products</div>
              </div>
              <div className="space-y-2">
                <div className="text-3xl font-bold text-primary">5K+</div>
                <div className="text-sm text-muted-foreground">Happy Customers</div>
              </div>
              <div className="space-y-2">
                <div className="text-3xl font-bold text-primary">500+</div>
                <div className="text-sm text-muted-foreground">Verified Sellers</div>
              </div>
              <div className="space-y-2">
                <div className="text-3xl font-bold text-primary">2M kg</div>
                <div className="text-sm text-muted-foreground">Plastic Saved</div>
              </div>
            </div>
          </div>
        </section>

        {/* Categories Section */}
        <section className="py-16">
          <div className="container mx-auto px-4">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold mb-4">Shop by Category</h2>
              <p className="text-muted-foreground max-w-2xl mx-auto">
                Explore our carefully curated categories of sustainable and eco-friendly products
              </p>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-5 gap-6">
              {[
                { name: "Home & Garden", icon: "🏡", href: "/category/home-garden" },
                { name: "Handmade", icon: "🎨", href: "/category/handmade" },
                { name: "Eco Gifts", icon: "🎁", href: "/category/eco-gifts" },
                { name: "Personal Care", icon: "🧴", href: "/category/personal-care" },
                { name: "Kitchen", icon: "🍽️", href: "/category/kitchen" },
                { name: "Footwear", icon: "👟", href: "/category/footwear" },
                { name: "Bags", icon: "👜", href: "/category/bags" },
                { name: "Stationery", icon: "📝", href: "/category/stationery" },
                { name: "Cleaning", icon: "🧽", href: "/category/cleaning" },
                { name: "Organic Food", icon: "🥬", href: "/category/organic-food" },
              ].map((category) => (
                <Link key={category.name} href={category.href}>
                  <Card className="hover:shadow-lg transition-shadow cursor-pointer group">
                    <CardContent className="p-6 text-center">
                      <div className="text-4xl mb-3">{category.icon}</div>
                      <h3 className="font-semibold group-hover:text-primary transition-colors">{category.name}</h3>
                    </CardContent>
                  </Card>
                </Link>
              ))}
            </div>
          </div>
        </section>

        {/* Featured Products */}
        <section className="py-16 bg-muted/30">
          <div className="container mx-auto px-4">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold mb-4">Featured Products</h2>
              <p className="text-muted-foreground">Handpicked eco-friendly products from our top-rated sellers</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              {[
                {
                  name: "Bamboo Toothbrush Set",
                  price: "$12.99",
                  originalPrice: "$16.99",
                  rating: 4.8,
                  image: "/placeholder-i5pda.png",
                  seller: "EcoLife Store",
                  badge: "Bestseller",
                },
                {
                  name: "Handwoven Jute Bag",
                  price: "$24.99",
                  originalPrice: "$29.99",
                  rating: 4.9,
                  image: "/handmade-jute-bag.png",
                  seller: "Artisan Crafts",
                  badge: "Handmade",
                },
                {
                  name: "Organic Cotton Towels",
                  price: "$34.99",
                  originalPrice: "$42.99",
                  rating: 4.7,
                  image: "/placeholder-eaun2.png",
                  seller: "Pure Living",
                  badge: "Organic",
                },
                {
                  name: "Recycled Paper Notebooks",
                  price: "$8.99",
                  originalPrice: "$12.99",
                  rating: 4.6,
                  image: "/recycled-paper-notebook.png",
                  seller: "Green Stationery",
                  badge: "Eco-Friendly",
                },
              ].map((product, index) => (
                <Card key={index} className="group hover:shadow-lg transition-shadow">
                  <CardContent className="p-0">
                    <div className="relative">
                      <Image
                        src={product.image || "/placeholder.svg"}
                        alt={product.name}
                        width={200}
                        height={200}
                        className="w-full h-48 object-cover rounded-t-lg"
                      />
                      <Badge className="absolute top-2 left-2 bg-primary">{product.badge}</Badge>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity"
                      >
                        <Heart className="h-4 w-4" />
                      </Button>
                    </div>
                    <div className="p-4 space-y-2">
                      <h3 className="font-semibold line-clamp-2">{product.name}</h3>
                      <div className="flex items-center space-x-1">
                        <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                        <span className="text-sm font-medium">{product.rating}</span>
                      </div>
                      <p className="text-sm text-muted-foreground">{product.seller}</p>
                      <div className="flex items-center space-x-2">
                        <span className="text-lg font-bold text-primary">{product.price}</span>
                        <span className="text-sm text-muted-foreground line-through">{product.originalPrice}</span>
                      </div>
                      <Button className="w-full" size="sm">
                        Add to Cart
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* Why Choose Us */}
        <section className="py-16">
          <div className="container mx-auto px-4">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold mb-4">Why Choose EcoMarket?</h2>
              <p className="text-muted-foreground max-w-2xl mx-auto">
                We're committed to making sustainable shopping accessible, reliable, and rewarding
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
              {[
                {
                  icon: <Leaf className="h-8 w-8 text-primary" />,
                  title: "100% Eco-Friendly",
                  description: "Every product is carefully vetted for environmental impact",
                },
                {
                  icon: <Award className="h-8 w-8 text-primary" />,
                  title: "Verified Sellers",
                  description: "All sellers are verified and committed to sustainability",
                },
                {
                  icon: <Truck className="h-8 w-8 text-primary" />,
                  title: "Carbon-Neutral Shipping",
                  description: "We offset the carbon footprint of every delivery",
                },
                {
                  icon: <Recycle className="h-8 w-8 text-primary" />,
                  title: "Plastic-Free Packaging",
                  description: "All orders ship in biodegradable or recyclable packaging",
                },
              ].map((feature, index) => (
                <div key={index} className="text-center space-y-4">
                  <div className="flex justify-center">{feature.icon}</div>
                  <h3 className="text-xl font-semibold">{feature.title}</h3>
                  <p className="text-muted-foreground">{feature.description}</p>
                </div>
              ))}
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  )
}
