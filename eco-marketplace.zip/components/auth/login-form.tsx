"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Loader2, Mail, Lock } from "lucide-react"
import { useAuth } from "@/lib/auth"
import { useRouter } from "next/navigation"
import Link from "next/link"

export function LoginForm() {
  const [buyerData, setBuyerData] = useState({ email: "", password: "" })
  const [sellerData, setSellerData] = useState({ email: "", password: "" })
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState("")
  const { login } = useAuth()
  const router = useRouter()

  const handleLogin = async (role: "buyer" | "seller") => {
    setLoading(true)
    setError("")

    const data = role === "buyer" ? buyerData : sellerData

    if (!data.email || !data.password) {
      setError("Please fill in all fields")
      setLoading(false)
      return
    }

    try {
      const success = await login(data.email, data.password, role)
      if (success) {
        router.push(role === "buyer" ? "/dashboard/buyer" : "/dashboard/seller")
      } else {
        setError("Invalid credentials")
      }
    } catch (err) {
      setError("Login failed. Please try again.")
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="max-w-md mx-auto">
      <Card>
        <CardHeader className="text-center">
          <CardTitle className="text-2xl">Welcome Back</CardTitle>
          <CardDescription>Sign in to your EcoMarket account</CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="buyer" className="w-full">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="buyer">Buyer</TabsTrigger>
              <TabsTrigger value="seller">Seller</TabsTrigger>
            </TabsList>

            <TabsContent value="buyer" className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="buyer-email">Email</Label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
                  <Input
                    id="buyer-email"
                    type="email"
                    placeholder="Enter your email"
                    className="pl-10"
                    value={buyerData.email}
                    onChange={(e) => setBuyerData({ ...buyerData, email: e.target.value })}
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="buyer-password">Password</Label>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
                  <Input
                    id="buyer-password"
                    type="password"
                    placeholder="Enter your password"
                    className="pl-10"
                    value={buyerData.password}
                    onChange={(e) => setBuyerData({ ...buyerData, password: e.target.value })}
                  />
                </div>
              </div>
              <Button className="w-full" onClick={() => handleLogin("buyer")} disabled={loading}>
                {loading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
                Sign In as Buyer
              </Button>
            </TabsContent>

            <TabsContent value="seller" className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="seller-email">Email</Label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
                  <Input
                    id="seller-email"
                    type="email"
                    placeholder="Enter your business email"
                    className="pl-10"
                    value={sellerData.email}
                    onChange={(e) => setSellerData({ ...sellerData, email: e.target.value })}
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="seller-password">Password</Label>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
                  <Input
                    id="seller-password"
                    type="password"
                    placeholder="Enter your password"
                    className="pl-10"
                    value={sellerData.password}
                    onChange={(e) => setSellerData({ ...sellerData, password: e.target.value })}
                  />
                </div>
              </div>
              <Button className="w-full" onClick={() => handleLogin("seller")} disabled={loading}>
                {loading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
                Sign In as Seller
              </Button>
            </TabsContent>
          </Tabs>

          {error && (
            <Alert className="mt-4">
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}

          <div className="mt-6 text-center space-y-2">
            <Link href="/forgot-password" className="text-sm text-primary hover:underline">
              Forgot your password?
            </Link>
            <div className="text-sm text-muted-foreground">
              Don't have an account?{" "}
              <Link href="/signup" className="text-primary hover:underline">
                Sign up here
              </Link>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
