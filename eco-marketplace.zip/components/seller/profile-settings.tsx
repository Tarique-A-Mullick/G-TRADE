"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Upload, Save, Star, Award } from "lucide-react"
import { useAuth } from "@/lib/auth"

export function ProfileSettings() {
  const { user, updateProfile } = useAuth()
  const [isEditing, setIsEditing] = useState(false)
  const [profileData, setProfileData] = useState({
    businessName: user?.businessName || "",
    description:
      "We specialize in eco-friendly products that make a positive impact on the environment. Our mission is to provide sustainable alternatives for everyday items.",
    phone: user?.phone || "",
    address: user?.address || "",
    website: "",
    socialMedia: {
      facebook: "",
      instagram: "",
      twitter: "",
    },
  })

  const handleSave = () => {
    updateProfile({
      businessName: profileData.businessName,
      phone: profileData.phone,
      address: profileData.address,
      description: profileData.description,
    })
    setIsEditing(false)
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Store Profile</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Profile Header */}
          <div className="flex items-start space-x-6">
            <div className="relative">
              <Avatar className="h-24 w-24">
                <AvatarImage src="/placeholder.svg" />
                <AvatarFallback className="text-2xl">{user?.businessName?.charAt(0) || "S"}</AvatarFallback>
              </Avatar>
              <Button
                size="sm"
                variant="outline"
                className="absolute -bottom-2 -right-2 h-8 w-8 rounded-full p-0 bg-transparent"
              >
                <Upload className="h-4 w-4" />
              </Button>
            </div>

            <div className="flex-1 space-y-3">
              <div className="flex items-center space-x-3">
                <h2 className="text-2xl font-bold">{user?.businessName}</h2>
                <Badge variant="outline" className="text-green-600">
                  <Award className="h-3 w-3 mr-1" />
                  Verified Seller
                </Badge>
              </div>

              <div className="flex items-center space-x-4">
                <div className="flex items-center">
                  <Star className="h-5 w-5 fill-yellow-400 text-yellow-400" />
                  <span className="font-medium ml-1">{user?.rating || "4.8"}</span>
                  <span className="text-muted-foreground ml-1">(324 reviews)</span>
                </div>
                <Badge variant="outline">156 Products</Badge>
                <Badge variant="outline">2.5K Followers</Badge>
              </div>
            </div>

            <Button variant={isEditing ? "outline" : "default"} onClick={() => setIsEditing(!isEditing)}>
              {isEditing ? "Cancel" : "Edit Profile"}
            </Button>
          </div>

          {/* Profile Form */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="businessName">Business Name</Label>
                <Input
                  id="businessName"
                  value={profileData.businessName}
                  onChange={(e) => setProfileData({ ...profileData, businessName: e.target.value })}
                  disabled={!isEditing}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="phone">Phone Number</Label>
                <Input
                  id="phone"
                  value={profileData.phone}
                  onChange={(e) => setProfileData({ ...profileData, phone: e.target.value })}
                  disabled={!isEditing}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="website">Website</Label>
                <Input
                  id="website"
                  value={profileData.website}
                  onChange={(e) => setProfileData({ ...profileData, website: e.target.value })}
                  placeholder="https://yourstore.com"
                  disabled={!isEditing}
                />
              </div>
            </div>

            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="address">Business Address</Label>
                <Textarea
                  id="address"
                  value={profileData.address}
                  onChange={(e) => setProfileData({ ...profileData, address: e.target.value })}
                  disabled={!isEditing}
                  rows={3}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="description">Store Description</Label>
                <Textarea
                  id="description"
                  value={profileData.description}
                  onChange={(e) => setProfileData({ ...profileData, description: e.target.value })}
                  disabled={!isEditing}
                  rows={4}
                />
              </div>
            </div>
          </div>

          {/* Social Media */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Social Media</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label htmlFor="facebook">Facebook</Label>
                <Input
                  id="facebook"
                  value={profileData.socialMedia.facebook}
                  onChange={(e) =>
                    setProfileData({
                      ...profileData,
                      socialMedia: { ...profileData.socialMedia, facebook: e.target.value },
                    })
                  }
                  placeholder="facebook.com/yourstore"
                  disabled={!isEditing}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="instagram">Instagram</Label>
                <Input
                  id="instagram"
                  value={profileData.socialMedia.instagram}
                  onChange={(e) =>
                    setProfileData({
                      ...profileData,
                      socialMedia: { ...profileData.socialMedia, instagram: e.target.value },
                    })
                  }
                  placeholder="instagram.com/yourstore"
                  disabled={!isEditing}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="twitter">Twitter</Label>
                <Input
                  id="twitter"
                  value={profileData.socialMedia.twitter}
                  onChange={(e) =>
                    setProfileData({
                      ...profileData,
                      socialMedia: { ...profileData.socialMedia, twitter: e.target.value },
                    })
                  }
                  placeholder="twitter.com/yourstore"
                  disabled={!isEditing}
                />
              </div>
            </div>
          </div>

          {isEditing && (
            <div className="flex justify-end space-x-2">
              <Button variant="outline" onClick={() => setIsEditing(false)}>
                Cancel
              </Button>
              <Button onClick={handleSave}>
                <Save className="h-4 w-4 mr-2" />
                Save Changes
              </Button>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
