"use client"

import { useState } from "react"
import { Home, Search, Heart, ShoppingCart, User, Menu, X } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import Link from "next/link"
import { useCart } from "@/lib/cart"
import { useAuth } from "@/lib/auth"
import { useLanguage } from "@/lib/translations"

export function MobileNav() {
  const [isOpen, setIsOpen] = useState(false)
  const { cart, wishlist } = useCart()
  const { isAuthenticated, user } = useAuth()
  const { t } = useLanguage()

  const navItems = [
    { icon: Home, label: "Home", href: "/" },
    { icon: Search, label: "Search", href: "/search" },
    { icon: Heart, label: "Wishlist", href: "/dashboard/buyer?tab=wishlist", badge: wishlist?.length || 0 },
    { icon: ShoppingCart, label: "Cart", href: "/cart", badge: cart?.length || 0 },
    {
      icon: User,
      label: isAuthenticated ? t("dashboard") : t("login"),
      href: isAuthenticated ? `/dashboard/${user?.role}` : "/login",
    },
  ]

  return (
    <>
      {/* Mobile Bottom Navigation */}
      <div className="fixed bottom-0 left-0 right-0 z-50 bg-white border-t border-gray-200 md:hidden">
        <div className="grid grid-cols-5 gap-1 py-2">
          {navItems.map((item, index) => (
            <Link key={index} href={item.href}>
              <Button variant="ghost" size="sm" className="flex flex-col items-center gap-1 h-auto py-2 relative">
                <item.icon className="h-5 w-5" />
                <span className="text-xs">{item.label}</span>
                {item.badge && item.badge > 0 && (
                  <Badge className="absolute -top-1 -right-1 h-5 w-5 rounded-full p-0 flex items-center justify-center text-xs">
                    {item.badge}
                  </Badge>
                )}
              </Button>
            </Link>
          ))}
        </div>
      </div>

      {/* Mobile Menu Sheet */}
      <Sheet open={isOpen} onOpenChange={setIsOpen}>
        <SheetTrigger asChild>
          <Button variant="ghost" size="sm" className="md:hidden">
            <Menu className="h-5 w-5" />
          </Button>
        </SheetTrigger>
        <SheetContent side="left" className="w-80">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-lg font-semibold">{t("menu")}</h2>
            <Button variant="ghost" size="sm" onClick={() => setIsOpen(false)}>
              <X className="h-4 w-4" />
            </Button>
          </div>

          <nav className="space-y-4">
            <div className="space-y-2">
              <h3 className="font-medium text-sm text-muted-foreground">Categories</h3>
              {Object.entries(t("categories")).map(([key, value]) => (
                <Link
                  key={key}
                  href={`/category/${key}`}
                  className="block py-2 text-sm hover:text-primary transition-colors"
                  onClick={() => setIsOpen(false)}
                >
                  {value}
                </Link>
              ))}
            </div>
          </nav>
        </SheetContent>
      </Sheet>
    </>
  )
}
