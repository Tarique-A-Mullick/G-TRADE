"use client"

import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Star, Heart, ShoppingCart } from "lucide-react"
import Image from "next/image"
import Link from "next/link"
import { useCart } from "@/lib/cart"
import type { Product } from "@/lib/products"

interface ProductCardProps {
  product: Product
}

export function ProductCard({ product }: ProductCardProps) {
  const { addToCart, addToWishlist, isInWishlist } = useCart()

  const discountPercentage = product.originalPrice
    ? Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100)
    : 0

  const handleAddToCart = () => {
    addToCart(product)
  }

  const handleToggleWishlist = () => {
    if (isInWishlist(product.id)) {
      // Would remove from wishlist - handled in wishlist component
    } else {
      addToWishlist(product)
    }
  }

  return (
    <Card className="group hover:shadow-lg transition-shadow duration-200">
      <CardContent className="p-0">
        <div className="relative">
          <Link href={`/product/${product.id}`}>
            <Image
              src={product.images[0] || "/placeholder.svg?height=200&width=200"}
              alt={product.name}
              width={200}
              height={200}
              className="w-full h-48 object-cover rounded-t-lg"
            />
          </Link>

          {/* Badges */}
          <div className="absolute top-2 left-2 flex flex-col gap-1">
            {product.tags.includes("bestseller") && (
              <Badge className="bg-primary text-primary-foreground">Bestseller</Badge>
            )}
            {product.tags.includes("handmade") && <Badge variant="secondary">Handmade</Badge>}
            {discountPercentage > 0 && <Badge className="bg-red-500 text-white">{discountPercentage}% OFF</Badge>}
          </div>

          {/* Wishlist Button */}
          <Button
            variant="ghost"
            size="sm"
            className={`absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity bg-white/80 hover:bg-white ${
              isInWishlist(product.id) ? "text-red-500" : ""
            }`}
            onClick={handleToggleWishlist}
          >
            <Heart className={`h-4 w-4 ${isInWishlist(product.id) ? "fill-current" : ""}`} />
          </Button>

          {/* Eco Features */}
          {product.ecoFeatures.length > 0 && (
            <div className="absolute bottom-2 left-2">
              <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                🌱 {product.ecoFeatures[0]}
              </Badge>
            </div>
          )}
        </div>

        <div className="p-4 space-y-2">
          <Link href={`/product/${product.id}`}>
            <h3 className="font-semibold line-clamp-2 hover:text-primary transition-colors">{product.name}</h3>
          </Link>

          {/* Rating */}
          <div className="flex items-center space-x-1">
            <div className="flex items-center">
              <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
              <span className="text-sm font-medium ml-1">{product.rating}</span>
            </div>
            <span className="text-sm text-muted-foreground">({product.totalReviews})</span>
          </div>

          {/* Seller */}
          <Link href={`/seller/${product.seller.id}`}>
            <p className="text-sm text-muted-foreground hover:text-primary transition-colors">
              by {product.seller.businessName}
            </p>
          </Link>

          {/* Price */}
          <div className="flex items-center space-x-2">
            <span className="text-lg font-bold text-primary">${product.price}</span>
            {product.originalPrice && (
              <span className="text-sm text-muted-foreground line-through">${product.originalPrice}</span>
            )}
          </div>

          {/* Shipping Info */}
          <div className="flex items-center space-x-2 text-xs text-muted-foreground">
            {product.shippingInfo.freeShipping && (
              <Badge variant="outline" className="text-xs">
                Free Shipping
              </Badge>
            )}
            {product.shippingInfo.carbonNeutral && (
              <Badge variant="outline" className="text-xs text-green-600">
                Carbon Neutral
              </Badge>
            )}
          </div>

          {/* Add to Cart Button */}
          <Button className="w-full" size="sm" onClick={handleAddToCart} disabled={!product.inStock}>
            <ShoppingCart className="h-4 w-4 mr-2" />
            {product.inStock ? "Add to Cart" : "Out of Stock"}
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}
