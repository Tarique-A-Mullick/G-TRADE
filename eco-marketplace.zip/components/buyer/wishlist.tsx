"use client"

import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Heart, ShoppingCart, Trash2 } from "lucide-react"
import Image from "next/image"
import Link from "next/link"
import { useCart } from "@/lib/cart"

export function Wishlist() {
  const { wishlist, removeFromWishlist, addToCart } = useCart()

  const handleAddToCart = (productId: string) => {
    const item = wishlist.find((item) => item.product.id === productId)
    if (item) {
      addToCart(item.product)
    }
  }

  return (
    <div className="space-y-6">
      {wishlist.length === 0 ? (
        <Card>
          <CardContent className="text-center py-12">
            <Heart className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
            <h3 className="text-lg font-semibold mb-2">Your wishlist is empty</h3>
            <p className="text-muted-foreground mb-4">Save products you love for later!</p>
            <Link href="/">
              <Button>Browse Products</Button>
            </Link>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {wishlist.map((item) => (
            <Card key={item.product.id} className="group hover:shadow-lg transition-shadow">
              <CardContent className="p-0">
                <div className="relative">
                  <Link href={`/product/${item.product.id}`}>
                    <Image
                      src={item.product.images[0] || "/placeholder.svg"}
                      alt={item.product.name}
                      width={200}
                      height={200}
                      className="w-full h-48 object-cover rounded-t-lg"
                    />
                  </Link>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="absolute top-2 right-2 bg-white/80 hover:bg-white text-red-500 hover:text-red-600"
                    onClick={() => removeFromWishlist(item.product.id)}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                  {item.product.ecoFeatures.length > 0 && (
                    <div className="absolute bottom-2 left-2">
                      <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                        🌱 {item.product.ecoFeatures[0]}
                      </Badge>
                    </div>
                  )}
                </div>

                <div className="p-4 space-y-3">
                  <Link href={`/product/${item.product.id}`}>
                    <h3 className="font-semibold line-clamp-2 hover:text-primary transition-colors">
                      {item.product.name}
                    </h3>
                  </Link>

                  <Link href={`/seller/${item.product.seller.id}`}>
                    <p className="text-sm text-muted-foreground hover:text-primary transition-colors">
                      by {item.product.seller.businessName}
                    </p>
                  </Link>

                  <div className="flex items-center space-x-2">
                    <span className="text-lg font-bold text-primary">${item.product.price}</span>
                    {item.product.originalPrice && (
                      <span className="text-sm text-muted-foreground line-through">${item.product.originalPrice}</span>
                    )}
                  </div>

                  <div className="flex space-x-2">
                    <Button
                      className="flex-1"
                      size="sm"
                      onClick={() => handleAddToCart(item.product.id)}
                      disabled={!item.product.inStock}
                    >
                      <ShoppingCart className="h-4 w-4 mr-2" />
                      Add to Cart
                    </Button>
                    <Button variant="outline" size="sm" onClick={() => removeFromWishlist(item.product.id)}>
                      <Heart className="h-4 w-4" />
                    </Button>
                  </div>

                  <p className="text-xs text-muted-foreground">Added {new Date(item.addedAt).toLocaleDateString()}</p>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  )
}
