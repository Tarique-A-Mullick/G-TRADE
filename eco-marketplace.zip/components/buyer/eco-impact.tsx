import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Leaf, Droplets, TreePine, Recycle } from "lucide-react"
import type { EcoImpact } from "@/lib/buyer-data"

interface EcoImpactProps {
  impact: EcoImpact
}

export function EcoImpactDisplay({ impact }: EcoImpactProps) {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center">
          <Leaf className="h-5 w-5 text-green-600 mr-2" />
          Your Eco Impact
        </CardTitle>
        <p className="text-sm text-muted-foreground">
          See the positive environmental impact of your sustainable shopping choices
        </p>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="text-center space-y-2">
            <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mx-auto">
              <Recycle className="h-6 w-6 text-green-600" />
            </div>
            <div>
              <p className="text-2xl font-bold text-green-600">{impact.plasticSaved}g</p>
              <p className="text-xs text-muted-foreground">Plastic Saved</p>
            </div>
          </div>

          <div className="text-center space-y-2">
            <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mx-auto">
              <Leaf className="h-6 w-6 text-blue-600" />
            </div>
            <div>
              <p className="text-2xl font-bold text-blue-600">{impact.carbonOffset}kg</p>
              <p className="text-xs text-muted-foreground">CO₂ Offset</p>
            </div>
          </div>

          <div className="text-center space-y-2">
            <div className="w-12 h-12 bg-emerald-100 rounded-full flex items-center justify-center mx-auto">
              <TreePine className="h-6 w-6 text-emerald-600" />
            </div>
            <div>
              <p className="text-2xl font-bold text-emerald-600">{impact.treesPlanted}</p>
              <p className="text-xs text-muted-foreground">Trees Planted</p>
            </div>
          </div>

          <div className="text-center space-y-2">
            <div className="w-12 h-12 bg-cyan-100 rounded-full flex items-center justify-center mx-auto">
              <Droplets className="h-6 w-6 text-cyan-600" />
            </div>
            <div>
              <p className="text-2xl font-bold text-cyan-600">{impact.waterSaved}L</p>
              <p className="text-xs text-muted-foreground">Water Saved</p>
            </div>
          </div>
        </div>

        <div className="mt-6 p-4 bg-green-50 rounded-lg">
          <div className="flex items-center space-x-2 mb-2">
            <Badge className="bg-green-600">Eco Champion</Badge>
            <span className="text-sm font-medium">Level 3</span>
          </div>
          <p className="text-sm text-muted-foreground">
            You've made {impact.totalOrders} sustainable purchases! Keep up the great work in protecting our planet.
          </p>
        </div>
      </CardContent>
    </Card>
  )
}
